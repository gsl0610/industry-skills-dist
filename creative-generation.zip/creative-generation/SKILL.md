---
name: creative-generation
description: 当用户需要生成营销素材（文案、配图、海报）、为产品/活动创作广告创意、生成社交媒体配图、制作商品主图或需要 AI 绘画能力时使用此技能。适用于电商大促、品牌种草、信息流广告、社媒配图等场景，支持中文文案生成与多风格 AI 配图。
version: 1.0.0
x-industry: marketing
x-owner: marketing-team
x-compliance: internal
visibility: shared
allowedTools:
  - read_file
  - execute_command
---

# 营销素材生成

## 何时使用

在以下任一情形使用本技能：

- 用户提供了产品/活动信息，要求生成营销文案与配图。
- 用户询问"帮我做一张图""生成广告素材""写个种草文案"。
- 用户要求生成特定风格、尺寸、文案的营销图片。
- 用户需要对生成的素材做合规自检（敏感词、版权提示）。

不适用场景：视频剪辑、直播推流、3D 建模——这些请转交其他技能。

## 执行步骤

按顺序执行，不得跳步：

1. **解析创意需求**
   从用户输入提取：产品/品牌、卖点、目标人群、使用场景（电商/社媒/信息流）、
   风格偏好、文案调性。关键字段缺失时先追问，不臆测。

2. **生成营销文案**
   依据 `references/copywriting-framework.md` 的文案框架，
   产出 2-3 版文案（主标题 + 副标题 + 正文 + CTA）。
   文案须符合 `references/creative-compliance.md` 的广告法红线。

3. **生成 AI 配图**
   运行 `scripts/generate_image.py` 调用腾讯云 AI 绘画（TextToImageLite）：
   - 把营销诉求转为绘图 Prompt（英文效果更佳，可由脚本自动翻译）
   - 选择风格代码（见 `references/image-styles.md`）
   - 指定分辨率（电商主图 1024:1024，社媒竖版 768:1024，横幅 1024:768）

   ```bash
   # 基础用法（Prompt 由脚本封装）
   TENCENTCLOUD_SECRET_ID=xxx TENCENTCLOUD_SECRET_KEY=xxx \
   python3 scripts/generate_image.py --prompt "一只橘猫在阳光下打盹，水彩风格" --style 201 --resolution 768:1024 --output /workspace/creative.png

   # 由营销需求自动构造 Prompt
   python3 scripts/generate_image.py --from-brief "产品:保温杯,卖点:24小时保温,风格:清新" --output /workspace/creative.png
   ```

4. **素材合规自检**
   运行 `scripts/check_compliance.py` 对文案做敏感词与广告法红线检查，
   产出合规自检报告。违规则标记并给出修改建议，不得直接交付违规素材。

5. **交付素材包**
   汇总产出：文案（markdown）+ 配图（png 路径）+ 合规报告，
   套用 `assets/creative-delivery-template.md` 输出交付包。

## 脚本与资源清单

### scripts/generate_image.py — AI 配图生成

调用腾讯云 AI 绘画 `TextToImageLite`（ap-guangzhou）。
仅依赖标准库 + tencentcloud-sdk（沙箱内 pip 安装）。
凭据从环境变量 `TENCENTCLOUD_SECRET_ID` / `TENCENTCLOUD_SECRET_KEY` 读取。

### scripts/check_compliance.py — 素材合规自检

基于 `references/creative-compliance.md` 的广告法红线词库做规则匹配，
输出违规项与修改建议。仅依赖标准库。

### 参考资料与模板

| 资源 | 用途 |
| --- | --- |
| `references/copywriting-framework.md` | 文案框架（AIDA/FAB/痛点-方案） |
| `references/creative-compliance.md` | 广告法红线 + 敏感词库 |
| `references/image-styles.md` | AI 绘画风格代码与适用场景 |
| `assets/creative-delivery-template.md` | 素材交付包模板 |

## 注意事项与边界

- **凭据安全**：SecretId/SecretKey 仅从环境变量读取，绝不可硬编码或写入产物（S1）。
- **API 地域**：TextToImageLite 仅 `ap-guangzhou` 可用，脚本已固化地域。
- **费用提示**：每次调用 AI 绘画产生计费，须在交付时告知用户调用次数与预估成本。
- **内容合规**：生成的图片可能涉及版权/肖像权，须提示"AI 生成内容仅供演示，商用前需确认版权"。
- **失败重试**：API 调用失败时脚本会重试 2 次；仍失败则返回错误码与建议。
- **文案 vs 配图独立**：文案生成不依赖配图，可单独交付；反之亦然。
