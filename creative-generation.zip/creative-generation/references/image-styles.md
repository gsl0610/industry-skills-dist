# AI 绘画风格代码

> 腾讯云 AI 绘画 TextToImageLite 的 Styles 参数。修改风格须同步更新本文件。

## 风格代码对照

| 代码 | 风格 | 适用场景 |
| --- | --- | --- |
| 201 | 清新/写实 | 电商主图、生活类、食品 |
| 202 | 商务/专业 | B 端、3C、金融、办公 |
| 205 | 动漫/二次元 | 美妆、服饰、Z 世代向 |
| 208 | 国风/水墨 | 文创、茶叶、国货品牌 |

## 分辨率推荐

| 用途 | 分辨率 | 说明 |
| --- | --- | --- |
| 社媒竖版（小红书/抖音封面） | 768:1024 | 竖版 3:4 |
| 电商主图（淘宝/京东） | 1024:1024 | 正方形 |
| 信息流横幅 | 1024:768 | 横版 4:3 |

## Prompt 构造要点

- 英文 Prompt 效果优于中文（模型训练数据偏向）
- 末尾加 "no text" 可减少画面乱码文字
- 产品类加 "product photography" 提升实拍感
- 避免指定具体品牌名（可能被拒或产生商标问题）

## 由营销需求构造 Prompt 的映射

`scripts/generate_image.py --from-brief` 的风格映射：

| 中文风格 | 英文风格描述 | 代码 |
| --- | --- | --- |
| 清新 | clean and fresh style, soft pastel colors | 201 |
| 商务 | professional business style, modern, minimal | 202 |
| 国风 | chinese traditional style, ink painting | 208 |
| 动漫 | anime style, vibrant colors | 205 |
| 写实 | photorealistic, high detail | 201 |
