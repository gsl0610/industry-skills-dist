# 营销素材交付包

## 一、创意需求

- 产品/品牌：{product}
- 目标人群：{audience}
- 使用场景：{scene}
- 风格调性：{tone}

## 二、营销文案（{framework} 框架）

### 文案 A
{copy_a}

### 文案 B
{copy_b}

## 三、AI 配图

| 序号 | Prompt | 风格 | 分辨率 | 文件路径 |
| --- | --- | --- | --- | --- |
| 1 | {prompt} | {style_name} | {resolution} | {image_path} |

> 提示：AI 生成内容仅供演示，商用前需确认版权与肖像权。

## 四、合规自检报告

| 规则 | 级别 | 违规词 | 修改建议 |
| --- | --- | --- | --- |
| {rule_id} | {level} | {term} | {suggestion} |

判定：{verdict}

## 五、费用提示

本次调用腾讯云 AI 绘画 {call_count} 次，预估成本 ¥{cost}。

---
*本交付包由 creative-generation 技能生成，文案框架见 references/copywriting-framework.md，
合规规则见 references/creative-compliance.md。*
