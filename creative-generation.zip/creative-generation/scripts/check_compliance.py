#!/usr/bin/env python3
"""营销素材合规自检：广告法红线 + 敏感词规则匹配。

仅依赖 Python 标准库。规则库见 references/creative-compliance.md。

用法：
    python3 check_compliance.py --text "全网最低价，买到就是赚到"
    python3 check_compliance.py --text-file copy.md
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any

# ── 广告法红线词库（出处：references/creative-compliance.md）──
# R-ABSOLUTE：绝对化用语，广告法明令禁止
ABSOLUTE_TERMS: tuple[str, ...] = (
    "国家级", "最高级", "最佳", "最先进", "最强", "最低价", "最便宜",
    "第一", "首个", "独家", "唯一", "顶级", "极品", "万能",
    "百分之百", "100%有效", "包治", "根治", "彻底", "永久",
    "零风险", "无风险", "稳赚", "必赚", "绝对",
)

# R-MEDICAL：非医疗产品宣称医疗效果
MEDICAL_CLAIMS: tuple[str, ...] = (
    "治疗", "治愈", "疗效", "药到病除", "包治百病",
    "降压", "降糖", "抗癌", "消炎", "杀菌",
)

# R-EXAGGERATE：虚假/夸大宣传
EXAGGERATE_TERMS: tuple[str, ...] = (
    "买到就是赚到", "错过再等一年", "史上最低",
    "万人疯抢", "抢疯了", "卖断货了",
)

# R-SENSITIVE：敏感词（政治/低俗/歧视，示例子集）
SENSITIVE_TERMS: tuple[str, ...] = (
    "赌博", "色情", "毒品",
)


def check_text(text: str) -> list[dict[str, Any]]:
    """对文案做合规自检。

    Args:
        text: 待检文案。

    Returns:
        list: 违规项列表，每项含 rule_id、level、term、suggestion。
    """
    issues: list[dict[str, Any]] = []

    for term in ABSOLUTE_TERMS:
        if term in text:
            issues.append({
                "rule_id": "R-ABSOLUTE",
                "level": "high",
                "term": term,
                "suggestion": f"「{term}」属绝对化用语，违反《广告法》第九条，须删除或改为可验证的客观表述。",
            })

    for term in MEDICAL_CLAIMS:
        if term in text:
            issues.append({
                "rule_id": "R-MEDICAL",
                "level": "high",
                "term": term,
                "suggestion": f"「{term}」涉及医疗效果宣称，非医疗产品不得使用，违反《广告法》第十七条。",
            })

    for term in EXAGGERATE_TERMS:
        if term in text:
            issues.append({
                "rule_id": "R-EXAGGERATE",
                "level": "medium",
                "term": term,
                "suggestion": f"「{term}」涉嫌夸大宣传，建议改为有数据支撑的客观表述。",
            })

    for term in SENSITIVE_TERMS:
        if term in text:
            issues.append({
                "rule_id": "R-SENSITIVE",
                "level": "high",
                "term": term,
                "suggestion": f"「{term}」属敏感词，必须删除。",
            })

    return issues


def main() -> int:
    """CLI 入口。检出 high 级违规时退出码为 1。"""
    parser = argparse.ArgumentParser(description="营销素材合规自检")
    parser.add_argument("--text", help="待检文案")
    parser.add_argument("--text-file", help="待检文案文件路径")
    args = parser.parse_args()

    if args.text_file:
        with open(args.text_file, encoding="utf-8") as fh:
            text = fh.read()
    elif args.text:
        text = args.text
    else:
        parser.error("必须指定 --text 或 --text-file")

    issues = check_text(text)
    result = {
        "text_length": len(text),
        "issue_count": len(issues),
        "high_count": sum(1 for i in issues if i["level"] == "high"),
        "issues": issues,
        "verdict": "不通过" if any(i["level"] == "high" for i in issues) else "通过",
    }
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    print()
    return 1 if result["high_count"] > 0 else 0


if __name__ == "__main__":
    sys.exit(main())
