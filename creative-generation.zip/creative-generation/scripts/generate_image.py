#!/usr/bin/env python3
"""营销配图生成：调用腾讯云 AI 绘画 TextToImageLite。

仅依赖标准库 + tencentcloud-sdk-python-aiart（沙箱内 pip 安装）。
凭据从环境变量读取，绝不可硬编码（S1）。

用法：
    # 直接指定 Prompt
    python3 generate_image.py --prompt "..." --style 201 --resolution 768:1024 --output out.png

    # 由营销需求自动构造 Prompt
    python3 generate_image.py --from-brief "产品:保温杯,卖点:24小时保温,风格:清新" --output out.png

环境变量（必需）：
    TENCENTCLOUD_SECRET_ID
    TENCENTCLOUD_SECRET_KEY
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
from typing import Any

# API 地域固定：TextToImageLite 仅 ap-guangzhou 可用（已实测确认）
REGION = "ap-guangzhou"
MAX_RETRIES = 2
RETRY_BACKOFF_SECONDS = 2


def build_prompt_from_brief(brief: str) -> tuple[str, str]:
    """由营销需求简述构造绘图 Prompt 与风格代码。

    Args:
        brief: 形如 "产品:保温杯,卖点:24小时保温,风格:清新" 的简述。

    Returns:
        tuple: (英文绘图 Prompt, 风格代码)。
    """
    fields: dict[str, str] = {}
    for part in brief.split(","):
        if ":" in part:
            key, _, value = part.partition(":")
            fields[key.strip()] = value.strip()

    product = fields.get("产品", fields.get("product", "a product"))
    selling_point = fields.get("卖点", fields.get("selling_point", ""))
    style_cn = fields.get("风格", fields.get("style", "clean"))

    style_map = {
        "清新": ("clean and fresh style, soft pastel colors, bright lighting", "201"),
        "商务": ("professional business style, modern, minimal", "202"),
        "国风": ("chinese traditional style, ink painting", "208"),
        "动漫": ("anime style, vibrant colors", "205"),
        "写实": ("photorealistic, high detail", "201"),
    }
    style_en, style_code = style_map.get(style_cn, ("clean and fresh style", "201"))

    prompt = f"marketing product photography of {product}, {selling_point}, {style_en}, high quality, no text"
    return prompt, style_code


def generate_image(prompt: str, style: str, resolution: str) -> bytes:
    """调用腾讯云 AI 绘画 TextToImageLite 生成图片。

    Args:
        prompt: 绘图 Prompt（英文效果更佳）。
        style: 风格代码（见 references/image-styles.md）。
        resolution: 分辨率，如 "768:1024"。

    Returns:
        bytes: PNG 图片字节。

    Raises:
        RuntimeError: 凭据缺失或 API 调用失败。
    """
    secret_id = os.environ.get("TENCENTCLOUD_SECRET_ID", "")
    secret_key = os.environ.get("TENCENTCLOUD_SECRET_KEY", "")
    if not secret_id or not secret_key:
        raise RuntimeError(
            "缺少腾讯云凭据：请设置环境变量 TENCENTCLOUD_SECRET_ID 与 "
            "TENCENTCLOUD_SECRET_KEY（S1：凭据仅从环境变量读取）。"
        )

    # 懒加载 SDK：未安装时自动 pip install（沙箱内首次运行约 30s）
    try:
        from tencentcloud.common import credential  # noqa: F401
    except ImportError:
        print("首次运行：自动安装腾讯云 SDK（约 30 秒）...", file=sys.stderr)
        import subprocess
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet", "tencentcloud-sdk-python-aiart"],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"自动安装 SDK 失败：{result.stderr[:500] or result.stdout[:500]}"
            )

    from tencentcloud.common import credential
    from tencentcloud.common.exception.tencent_cloud_sdk_exception import (
        TencentCloudSDKException,
    )
    from tencentcloud.aiart.v20221229 import aiart_client, models

    cred = credential.Credential(secret_id, secret_key)
    client = aiart_client.AiartClient(cred, REGION)

    last_error: str = ""
    for attempt in range(1, MAX_RETRIES + 2):
        try:
            req = models.TextToImageLiteRequest()
            req.from_json_string(
                json.dumps(
                    {
                        "Prompt": prompt,
                        "Styles": [style],
                        "ResultConfig": {"Resolution": resolution},
                    }
                )
            )
            resp = client.TextToImageLite(req)
            if not resp.ResultImage:
                raise RuntimeError("API 返回成功但无图片数据。")
            return base64.b64decode(resp.ResultImage)
        except TencentCloudSDKException as exc:
            last_error = f"{exc.code}: {exc.message}"
            # 限频类错误才重试
            if "LimitExceeded" not in (exc.code or "") and "RequestLimit" not in (
                exc.code or ""
            ):
                break
        except Exception as exc:  # noqa: BLE001
            last_error = str(exc)

        if attempt <= MAX_RETRIES:
            time.sleep(RETRY_BACKOFF_SECONDS * attempt)

    raise RuntimeError(f"AI 绘画调用失败（重试 {MAX_RETRIES} 次后仍失败）：{last_error}")


def main() -> int:
    """CLI 入口。"""
    parser = argparse.ArgumentParser(description="营销配图生成（腾讯云 AI 绘画）")
    parser.add_argument("--prompt", help="绘图 Prompt（英文效果更佳）")
    parser.add_argument("--from-brief", help='营销需求简述，如 "产品:保温杯,卖点:24h保温,风格:清新"')
    parser.add_argument("--style", default="201", help="风格代码（默认 201，见 references/image-styles.md）")
    parser.add_argument("--resolution", default="768:1024", help="分辨率（默认 768:1024 竖版）")
    parser.add_argument("--output", default="/workspace/creative.png", help="输出文件路径")
    args = parser.parse_args()

    if args.from_brief:
        prompt, style = build_prompt_from_brief(args.from_brief)
    elif args.prompt:
        prompt, style = args.prompt, args.style
    else:
        parser.error("必须指定 --prompt 或 --from-brief")

    print(f"Prompt: {prompt}", file=sys.stderr)
    print(f"Style: {style}  Resolution: {resolution_str(args.resolution)}", file=sys.stderr)
    print(f"调用腾讯云 AI 绘画（{REGION}）...", file=sys.stderr)

    image_data = generate_image(prompt, style, args.resolution)

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "wb") as fh:
        fh.write(image_data)

    print(
        json.dumps(
            {
                "status": "success",
                "output": args.output,
                "size_bytes": len(image_data),
                "prompt": prompt,
                "style": style,
                "resolution": args.resolution,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def resolution_str(value: str) -> str:
    """分辨率字符串透传。"""
    return value


if __name__ == "__main__":
    sys.exit(main())
