#!/bin/bash
# 调后端 API 生成营销配图（沙箱内无腾讯云凭据，必须走后端代为调用）。
# 用法：./gen_image.sh "prompt 文本" "201" "1024:1024" [output_path]
set -e

PROMPT="${1:?用法: gen_image.sh <prompt> <style> <resolution> [output_path]}"
STYLE="${2:-201}"
RESOLUTION="${3:-1024:1024}"
OUTPUT="${4:-/workspace/creative.png}"
BACKEND_URL="${BACKEND_URL:-http://122.51.100.240:8000}"
TENANT_ID="${TENANT_ID:-demo-tenant}"
USER_ID="${USER_ID:-demo-user}"

mkdir -p "$(dirname "$OUTPUT")"

echo "调用后端 API 生成图片..." >&2
RESP=$(curl -s -X POST "$BACKEND_URL/v1/skills/creative-generation/generate" \
  -H "Content-Type: application/json" \
  -H "X-Tenant-Id: $TENANT_ID" \
  -H "X-User-Id: $USER_ID" \
  -d "{\"prompt\":$(echo "$PROMPT" | python3 -c 'import sys,json;print(json.dumps(sys.stdin.read().rstrip()))'),\"style\":\"$STYLE\",\"resolution\":\"$RESOLUTION\"}")

# 检查错误
if echo "$RESP" | grep -q '"detail"'; then
  echo "后端返回错误：$RESP" >&2
  exit 1
fi

# 提取 base64 并写文件
echo "$RESP" | python3 -c "
import sys, json, base64
d = json.load(sys.stdin)
img = d.get('image_base64', '')
if not img:
    print('响应中没有 image_base64 字段', file=sys.stderr)
    sys.exit(1)
open(sys.argv[1], 'wb').write(base64.b64decode(img))
print(f\"已保存到 {sys.argv[1]}（{d.get('size_bytes', '?')} 字节）\", file=sys.stderr)
" "$OUTPUT"

echo "$OUTPUT"
