#!/bin/bash
# 调后端 API 生成营销配图（沙箱内无腾讯云凭据，必须走后端代为调用）。
# 后端会生成图片后自动上传到 COS，返回公网 URL（前端可直接 <img src=...>）。
# 用法：./gen_image.sh "prompt 文本" "201" "1024:1024"
set -e

PROMPT="${1:?用法: gen_image.sh <prompt> <style> <resolution>}"
STYLE="${2:-201}"
RESOLUTION="${3:-1024:1024}"
BACKEND_URL="${BACKEND_URL:-http://122.51.100.240:8000}"
TENANT_ID="${TENANT_ID:-demo-tenant}"
USER_ID="${USER_ID:-demo-user}"

echo "调用后端 API 生成图片并上传 COS..." >&2

# 用 python 做 json 编码避免 shell 转义问题
PAYLOAD=$(python3 -c "import json,sys; print(json.dumps({'prompt': sys.argv[1], 'style': sys.argv[2], 'resolution': sys.argv[3]}))" "$PROMPT" "$STYLE" "$RESOLUTION")

RESP=$(curl -s -X POST "$BACKEND_URL/v1/skills/creative-generation/generate" \
  -H "Content-Type: application/json" \
  -H "X-Tenant-Id: $TENANT_ID" \
  -H "X-User-Id: $USER_ID" \
  -d "$PAYLOAD")

# 检查错误响应
if echo "$RESP" | grep -q '"detail"'; then
  echo "后端返回错误：$RESP" >&2
  exit 1
fi

# 提取 image_url 写到文件
echo "$RESP" | python3 -c "
import sys, json
d = json.load(sys.stdin)
url = d.get('image_url', '')
if not url:
    print('响应中没有 image_url 字段', file=sys.stderr)
    sys.exit(1)
# 写到多个位置：根目录的 image_url.txt（方便智能体读）
with open('/workspace/image_url.txt', 'w') as f:
    f.write(url)
# 同时打印到 stdout（Agent 工具结果能直接看到）
print('image_url:', url)
print('size_bytes:', d.get('size_bytes', '?'))
print('cost_note:', d.get('cost_note', ''))
"
