---
name: intelligent-outbound-call
description: 当用户需要规划智能外呼营销方案、设计外呼话术、预估外呼接通率与转化率、或做外呼任务排期与容量规划时使用此技能。适用于电销、客户回访、到期提醒、活动通知等外呼触达场景。
version: 1.0.0
x-industry: marketing
x-owner: marketing-team
x-compliance: internal
visibility: internal
allowedTools:
  - read_file
  - execute_command
---

# 智能外呼触达

## 何时使用

在以下任一情形使用本技能：

- 用户要求制定外呼营销方案（话术、排期、容量）。
- 用户询问"外呼接通率多少""打多少通能转化""外呼成本怎么算"。
- 用户要求设计外呼话术脚本（开场/挖掘/异议处理/促单）。
- 用户要求做外呼任务排期与并发容量规划。

不适用场景：短信/邮件触达、IM 私域运营（用 CRM 相关技能）。

## 执行步骤

1. **解析外呼需求**
   提取：外呼目的（电销/回访/提醒）、目标人群、外呼量、并发数、话术方向。

2. **生成话术脚本**
   运行 `scripts/script_generator.py` 生成外呼话术：
   - 输入：目的、产品、人群
   - 输出：开场白 + 需求挖掘 + 产品介绍 + 异议处理 + 促单 + 结束语

   ```bash
   python3 scripts/script_generator.py --purpose telesales --product "保险续保" --audience "到期客户"
   ```

3. **预估接通与转化**
   运行 `scripts/call_estimator.py` 估算：
   - 输入：外呼量、并发数、时段、人群质量
   - 输出：接通率、有效通话、转化率、外呼成本、人力需求

   ```bash
   python3 scripts/call_estimator.py --volume 10000 --concurrency 20 --slot evening --quality high
   ```

4. **排期与容量规划**
   运行 `scripts/capacity_planner.py` 生成排期：
   - 输入：总外呼量、截止日期、并发上限
   - 输出：分日排期 + 人力配置 + 预计完成时间

   ```bash
   python3 scripts/capacity_planner.py --volume 50000 --deadline 7 --max-concurrency 30
   ```

5. **产出外呼方案**
   套用 `assets/outbound-plan-template.md` 输出。

## 脚本与资源清单

| 脚本 | 用途 |
| --- | --- |
| `scripts/script_generator.py` | 外呼话术生成（模拟） |
| `scripts/call_estimator.py` | 接通率与转化预估（模拟） |
| `scripts/capacity_planner.py` | 排期与容量规划（模拟） |

| 资源 | 用途 |
| --- | --- |
| `references/call-script-framework.md` | 话术框架与异议处理库 |
| `references/call-benchmarks.md` | 外呼接通/转化行业基准 |
| `assets/outbound-plan-template.md` | 外呼方案模板 |

## 注意事项与边界

- **全部模拟**：接通率与转化为模拟值，须标注。
- **合规红线**：外呼须符合《通信短消息服务管理规定》与外呼白名单要求，
  须提示"须取得用户同意、提供退订方式、不得骚扰"。
- **时段限制**：外呼时段须在 9:00-21:00，夜间外呼违规。
- **不保证转化**：预估为模拟值，不得承诺效果。
