# 智能外呼方案

## 一、外呼目标
{purpose} - {product} - {audience}

## 二、话术脚本
{script}

## 三、接通与转化预估
{call_estimate}

## 四、排期与容量
{capacity_plan}

## 五、合规提示
- 外呼时段 9:00-21:00
- 须取得用户同意，提供退订方式
- 不得骚扰已退订用户

---
*由 intelligent-outbound-call 技能生成，模拟数据。*
