#!/usr/bin/env python3
"""外呼话术生成与接通率预估（模拟）。

仅依赖 Python 标准库。合并 script_generator 与 call_estimator 功能。

用法：
    python3 script_generator.py --purpose telesales --product "保险续保" --audience "到期客户"
    python3 script_generator.py --demo
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any

PURPOSE_LABELS = {"telesales": "电话营销", "callback": "客户回访", "reminder": "到期提醒"}

SLOT_BASE = {"morning": 0.15, "afternoon": 0.25, "evening": 0.35}
QUALITY_MULT = {"high": 1.1, "medium": 1.0, "low": 0.8}


def generate_script(purpose: str, product: str, audience: str) -> dict[str, Any]:
    """生成六段式外呼话术。"""
    label = PURPOSE_LABELS.get(purpose, purpose)
    return {
        "purpose": label,
        "product": product,
        "audience": audience,
        "script": {
            "opening": f"您好，我是{product}专属顾问，今天致电是想向您介绍为{audience}提供的专属方案，请问方便聊两分钟吗？",
            "need_discovery": [
                f"请问您目前是否有在使用类似{product}的服务？",
                f"在{product}方面，您最关注的是哪些方面？",
            ],
            "product_intro": f"针对{audience}的需求，我们的{product}有以下优势：1.覆盖全面；2.性价比高；3.灵活可选。",
            "objection_handling": [
                {"objection": "价格太贵了", "response": f"平均每天不到一杯咖啡的钱，且{product}包含多项权益，综合性价比更高。"},
                {"objection": "我已经有类似产品", "response": "可以帮您做免费方案对比，看看是否有升级空间。"},
                {"objection": "我需要考虑一下", "response": "活动优惠到本月底截止，我先把资料发您参考。"},
            ],
            "closing": f"感谢您的时间，如需了解{product}详情，随时联系我，祝您生活愉快。",
        },
    }


def estimate_calls(volume: int, concurrency: int, slot: str, quality: str) -> dict[str, Any]:
    """预估接通率与转化。"""
    base = SLOT_BASE.get(slot, 0.20)
    mult = QUALITY_MULT.get(quality, 1.0)
    connect_rate = min(base * mult, 0.50)
    connected = int(volume * connect_rate)
    effective = int(connected * 0.70)
    conv_rate = 0.03 * mult
    conversions = int(effective * conv_rate)
    cost_per_call = 0.5
    total_cost = round(volume * cost_per_call, 2)
    hours_needed = round(volume / max(concurrency * 60, 1), 1)
    return {
        "volume": volume,
        "concurrency": concurrency,
        "slot": slot,
        "connect_rate_percent": round(connect_rate * 100, 2),
        "connected_calls": connected,
        "effective_calls": effective,
        "conversion_rate_percent": round(conv_rate * 100, 2),
        "conversions": conversions,
        "total_cost": total_cost,
        "cost_per_conversion": round(total_cost / max(conversions, 1), 2),
        "estimated_hours": hours_needed,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="外呼话术生成与接通率预估（模拟）")
    parser.add_argument("--purpose", choices=["telesales", "callback", "reminder"], default="telesales")
    parser.add_argument("--product", default="保险续保")
    parser.add_argument("--audience", default="到期客户")
    parser.add_argument("--volume", type=int, default=10000)
    parser.add_argument("--concurrency", type=int, default=20)
    parser.add_argument("--slot", choices=["morning", "afternoon", "evening"], default="evening")
    parser.add_argument("--quality", choices=["high", "medium", "low"], default="high")
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()

    result = {
        "script": generate_script(args.purpose, args.product, args.audience),
        "call_estimate": estimate_calls(args.volume, args.concurrency, args.slot, args.quality),
        "note": "模拟数据，非真实外呼结果。接通率基于行业基准。",
    }
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
