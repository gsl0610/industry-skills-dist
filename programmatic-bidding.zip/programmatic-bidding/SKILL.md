---
name: programmatic-bidding
description: 当用户需要做程序化广告投放方案、圈选受众、制定出价策略、模拟竞价与预估曝光点击成本、或评估投放预算分配时使用此技能。适用于信息流广告、DSP 投放、RTA 策略、效果广告预算规划等场景。
version: 1.0.0
x-industry: marketing
x-owner: marketing-team
x-compliance: internal
visibility: internal
allowedTools:
  - read_file
  - execute_command
---

# 程序化投放触达

## 何时使用

在以下任一情形使用本技能：

- 用户提供了投放预算、目标人群、渠道，要求产出投放方案。
- 用户询问"这笔预算怎么花""出多少价""预估多少曝光"。
- 用户要求模拟竞价、评估不同出价策略的效果。
- 用户要求做受众圈选与预算分配。

不适用场景：素材制作（用 creative-generation）、效果归因分析（用效果分析技能）。

## 执行步骤

按顺序执行，不得跳步：

1. **解析投放需求**
   从用户输入提取：预算、目标人群、投放渠道、计费方式（CPM/CPC/oCPM）、
   KPI 目标（CPA/ROI）。关键字段缺失时先追问。

2. **受众圈选**
   运行 `scripts/audience_selector.py` 模拟受众包生成：
   - 输入人群标签与规模
   - 输出受众包画像（年龄/性别/兴趣/地域分布）+ 预估可达规模

   ```bash
   python3 scripts/audience_selector.py --audience "25-35女性,美妆兴趣,一二线" --size 1000000
   ```

3. **出价策略**
   运行 `scripts/bidding_strategy.py` 生成出价方案：
   - 输入预算、计费方式、KPI 目标
   - 输出建议出价曲线（分时段/分版位）+ 预估曝光/点击/成本

   ```bash
   python3 scripts/bidding_strategy.py --budget 50000 --billing oCPM --target-cpa 50 --audience-size 1000000
   ```

4. **竞价模拟**
   运行 `scripts/bidding_simulator.py` 模拟竞价过程：
   - 基于出价与受众竞争度，模拟 N 次竞价
   - 输出胜出率、实际 CPM/CPC、曝光量、点击量

   ```bash
   python3 scripts/bidding_simulator.py --bid 30 --competition high --impressions 100000
   ```

5. **产出投放方案**
   汇总受众包 + 出价策略 + 竞价模拟结果，
   套用 `assets/bidding-plan-template.md` 输出投放方案。

## 脚本与资源清单

### scripts/audience_selector.py — 受众圈选（模拟）

模拟受众包画像生成。仅依赖标准库，用确定性的分布模型生成画像数据。

### scripts/bidding_strategy.py — 出价策略（模拟）

根据预算与 KPI 目标生成出价曲线与预估。仅依赖标准库。

### scripts/bidding_simulator.py — 竞价模拟（模拟）

模拟二价竞价（GSP）过程，输出胜出率与实际成本。仅依赖标准库。

### 参考资料与模板

| 资源 | 用途 |
| --- | --- |
| `references/bidding-glossary.md` | 程序化广告术语口径（CPM/CPC/oCPM/GSP/RTB 等） |
| `references/audience-taxonomy.md` | 受众标签体系与圈选规则 |
| `assets/bidding-plan-template.md` | 投放方案模板 |

## 注意事项与边界

- **全部模拟**：本技能不接真实广告 API，所有数据为规则模拟，须在产出中标注"模拟数据"。
- **口径一致**：CPM/CPC 等术语口径以 `references/bidding-glossary.md` 为准。
- **预算约束**：出价策略须保证总花费不超过预算；超预算时降配而非透支。
- **不保证效果**：预估曝光/点击为模拟值，不得表述为"保证达成"。
- **合规提示**：涉及用户数据的受众圈选须提示"须符合《个人信息保护法》"。
