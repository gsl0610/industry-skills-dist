# 程序化投放方案

## 一、投放概要

- 产品/目标：{product}
- 投放渠道：{channel}
- 计费方式：{billing}
- 总预算：¥{budget}
- KPI 目标：CPA ≤ ¥{target_cpa}

## 二、受众包

| 维度 | 分布 |
| --- | --- |
| 年龄 | {age_distribution} |
| 性别 | {gender} |
| 城市 | {city_tier} |
| 兴趣 | {interests} |

可达规模：{reachable}（触达率 {reach_rate}%）

## 三、出价策略

建议出价：¥{suggested_bid}（基准 ¥{base_bid}）

| 时段 | 出价 |
| --- | --- |
| 00-06 | ¥{bid_00_06} |
| 06-12 | ¥{bid_06_12} |
| 12-18 | ¥{bid_12_18} |
| 18-24 | ¥{bid_18_24} |

## 四、竞价模拟

| 指标 | 值 |
| --- | --- |
| 胜出率 | {win_rate}% |
| 实际 CPM | ¥{actual_cpm} |
| 实际 CPC | ¥{actual_cpc} |
| 总花费 | ¥{total_spent} |

## 五、预估效果

| 指标 | 预估值 |
| --- | --- |
| 曝光量 | {impressions} |
| 点击量 | {clicks} |
| 转化量 | {conversions} |
| 预估 CPA | ¥{estimated_cpa} |
| 预估 CPC | ¥{estimated_cpc} |
| CTR | {ctr}% |
| CVR | {cvr}% |

> 以上为模拟预估数据，非真实投放结果。CTR/CVR 为行业假设值，
> 实际效果受素材质量、竞争环境、季节因素等影响。

## 六、合规提示

- 受众圈选涉及用户数据，须符合《个人信息保护法》与平台数据使用规范。
- 预估效果为模拟值，不得表述为"保证达成"。
- 实际投放须在广告平台完成资质审核与素材审核后进行。

---
*本方案由 programmatic-bidding 技能生成，术语口径见 references/bidding-glossary.md。*
