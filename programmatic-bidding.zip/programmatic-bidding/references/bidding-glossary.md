# 程序化广告术语口径

> 本文档是出价与预估指标的**唯一口径依据**。所有 CPM/CPC 等术语
> 必须以此定义为准，不得混用。

## 计费方式

| 术语 | 全称 | 定义 |
| --- | --- | --- |
| CPM | Cost Per Mille | 千次曝光成本，按曝光计费 |
| CPC | Cost Per Click | 单次点击成本，按点击计费 |
| oCPM | optimized CPM | 优化千次曝光，按曝光计费但系统按转化目标优化出价 |
| CPA | Cost Per Action | 单次转化成本，按转化计费（或 oCPM 达成） |
| oCPC | optimized CPC | 优化点击，按点击计费但系统按转化目标优化出价 |

## 核心指标

| 术语 | 公式 | 说明 |
| --- | --- | --- |
| CTR | 点击 ÷ 曝光 | 点击率 |
| CVR | 转化 ÷ 点击 | 转化率 |
| CPA | 花费 ÷ 转化数 | 单次转化成本 |
| ROI | 转化价值 ÷ 花费 | 投入产出比 |
| Reach | 达到人群数 | 去重后的曝光人数 |
| Frequency | 曝光 ÷ Reach | 频次 |

## 竞价模型

| 术语 | 说明 |
| --- | --- |
| GSP | Generalized Second-Price，二价竞价，胜者支付第二高价 |
| RTB | Real-Time Bidding，实时竞价 |
| DSP | Demand-Side Platform，需求方平台 |
| SSP | Supply-Side Platform，供给方平台 |
| RTA | Real-Time API，实时接口，广告主在竞价前实时返回是否参与 |

## 口径注意事项

- CPM 的 Mille 是千次，不是百万次
- oCPM/oCPC 仍按曝光/点击计费，只是出价策略优化，计费方式不变
- CPA 在 oCPM 模式下是"达成成本"而非"计费方式"
- Reach 须去重，Frequency = 曝光 / Reach
