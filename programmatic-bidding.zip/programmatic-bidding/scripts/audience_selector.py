#!/usr/bin/env python3
"""受众圈选模拟：根据人群标签生成受众包画像。

仅依赖标准库，用确定性分布模型生成画像数据（非真实数据）。

用法：
    python3 audience_selector.py --audience "25-35女性,美妆兴趣,一二线" --size 1000000
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from typing import Any

# 受众标签→画像分布映射（出处：references/audience-taxonomy.md）
# 用确定性哈希保证同样输入产出同样结果，便于复现
AUDIENCE_PROFILES: dict[str, dict[str, Any]] = {
    "25-35女性,美妆兴趣,一二线": {
        "age_distribution": {"25-29": 0.45, "30-35": 0.55},
        "gender": {"female": 0.92, "male": 0.08},
        "city_tier": {"一线": 0.40, "二线": 0.45, "三线及以下": 0.15},
        "interests": ["美妆护肤", "时尚穿搭", "健康生活", "美食", "旅行"],
        "active_hours": {"早": 0.15, "午": 0.25, "晚": 0.45, "夜": 0.15},
    },
    "18-24男女,游戏兴趣,全国": {
        "age_distribution": {"18-20": 0.30, "21-24": 0.70},
        "gender": {"female": 0.40, "male": 0.60},
        "city_tier": {"一线": 0.20, "二线": 0.30, "三线及以下": 0.50},
        "interests": ["游戏", "动漫", "数码", "短视频", "音乐"],
        "active_hours": {"早": 0.10, "午": 0.20, "晚": 0.40, "夜": 0.30},
    },
}


def resolve_profile(audience: str) -> dict[str, Any]:
    """根据受众描述解析画像，未命中则用默认分布。

    Args:
        audience: 受众描述字符串。

    Returns:
        dict: 画像分布。
    """
    for key, profile in AUDIENCE_PROFILES.items():
        if key in audience or audience in key:
            return profile
    # 默认画像：均匀分布
    return {
        "age_distribution": {"18-24": 0.25, "25-35": 0.40, "36-45": 0.25, "46+": 0.10},
        "gender": {"female": 0.50, "male": 0.50},
        "city_tier": {"一线": 0.25, "二线": 0.35, "三线及以下": 0.40},
        "interests": ["综合"],
        "active_hours": {"早": 0.20, "午": 0.25, "晚": 0.40, "夜": 0.15},
    }


def estimate_reach(size: int, profile: dict[str, Any]) -> dict[str, Any]:
    """预估可达规模（模拟）。

    Args:
        size: 输入人群规模。
        profile: 画像分布。

    Returns:
        dict: 含可达规模与触达率。
    """
    # 模拟：可达规模约为输入的 60%-85%，与画像竞争度相关
    h = int(hashlib.md5(json.dumps(profile, sort_keys=True).encode()).hexdigest(), 16)
    reach_rate = 0.60 + (h % 26) / 100  # 0.60 ~ 0.85
    reachable = int(size * reach_rate)
    return {
        "input_size": size,
        "reachable": reachable,
        "reach_rate": round(reach_rate, 4),
    }


def main() -> int:
    """CLI 入口。"""
    parser = argparse.ArgumentParser(description="受众圈选模拟")
    parser.add_argument("--audience", required=True, help="人群描述，如 '25-35女性,美妆兴趣,一二线'")
    parser.add_argument("--size", type=int, default=1000000, help="输入人群规模")
    args = parser.parse_args()

    profile = resolve_profile(args.audience)
    reach = estimate_reach(args.size, profile)

    result = {
        "audience": args.audience,
        "profile": profile,
        "reach_estimate": reach,
        "note": "模拟数据，非真实受众画像。实际圈选须对接 DMP/CDP。",
    }
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
