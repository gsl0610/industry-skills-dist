#!/usr/bin/env python3
"""竞价模拟：模拟二价竞价（GSP）过程，输出胜出率与实际成本。

仅依赖标准库，模拟逻辑。

用法：
    python3 bidding_simulator.py --bid 30 --competition high --impressions 100000
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from typing import Any

# 竞争强度→对手出价分布参数
COMPETITION_PROFILES: dict[str, dict[str, float]] = {
    "low": {"mean": 15.0, "std": 5.0, "win_rate_base": 0.85},
    "medium": {"mean": 25.0, "std": 8.0, "win_rate_base": 0.55},
    "high": {"mean": 35.0, "std": 10.0, "win_rate_base": 0.30},
}


def simulate_auction(bid: float, competition: str, impressions: int) -> dict[str, Any]:
    """模拟 GSP 竞价过程。

    Args:
        bid: 己方出价（CPM 元）。
        competition: 竞争强度 low/medium/high。
        impressions: 模拟曝光机会数。

    Returns:
        dict: 胜出次数、实际 CPM、总花费、胜出率。
    """
    profile = COMPETITION_PROFILES.get(competition, COMPETITION_PROFILES["medium"])
    rng = random.Random(hash(f"{bid}{competition}{impressions}").bit_length())

    wins = 0
    total_cost = 0.0
    for _ in range(impressions):
        # 对手出价（正态分布截断到非负）
        opponent = max(0.0, rng.gauss(profile["mean"], profile["std"]))
        if bid >= opponent:
            wins += 1
            # GSP：实际支付第二高价
            total_cost += opponent

    actual_cpm = round(total_cost / max(wins, 1), 2)
    win_rate = round(wins / max(impressions, 1), 4)
    total_spent = round(total_cost / 1000, 2)  # CPM 转总花费

    return {
        "bid": bid,
        "competition": competition,
        "impressions_opportunities": impressions,
        "wins": wins,
        "win_rate": win_rate,
        "actual_cpm": actual_cpm,
        "actual_cpc": round(actual_cpm / max(0.015 * 1000, 1) * 1000, 2),
        "total_spent": total_spent,
        "note": "模拟数据，基于 GSP 二价竞价模型。实际竞价受平台算法影响。",
    }


def main() -> int:
    """CLI 入口。"""
    parser = argparse.ArgumentParser(description="竞价模拟")
    parser.add_argument("--bid", type=float, required=True, help="己方出价（CPM 元）")
    parser.add_argument(
        "--competition", choices=["low", "medium", "high"], default="medium", help="竞争强度"
    )
    parser.add_argument("--impressions", type=int, default=100000, help="模拟曝光机会数")
    args = parser.parse_args()

    result = simulate_auction(args.bid, args.competition, args.impressions)
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
