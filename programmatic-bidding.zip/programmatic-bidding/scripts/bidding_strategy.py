#!/usr/bin/env python3
"""出价策略生成：根据预算与 KPI 目标产出出价曲线与预估。

仅依赖标准库，模拟出价逻辑。

用法：
    python3 bidding_strategy.py --budget 50000 --billing oCPM --target-cpa 50 --audience-size 1000000
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any

# 计费方式→默认出价基数（模拟基准，出处：references/bidding-glossary.md）
BASE_BID: dict[str, float] = {
    "CPM": 30.0,
    "CPC": 2.0,
    "oCPM": 25.0,
}


def generate_strategy(
    budget: float, billing: str, target_cpa: float, audience_size: int
) -> dict[str, Any]:
    """生成出价策略与预估。

    Args:
        budget: 总预算（元）。
        billing: 计费方式。
        target_cpa: 目标 CPA（元）。
        audience_size: 受众规模。

    Returns:
        dict: 出价策略与预估指标。
    """
    base = BASE_BID.get(billing, 30.0)
    suggested_bid = round(target_cpa * 0.7, 2)

    hourly_bid = {
        "00-06": round(suggested_bid * 0.5, 2),
        "06-12": round(suggested_bid * 0.9, 2),
        "12-18": round(suggested_bid * 1.0, 2),
        "18-24": round(suggested_bid * 1.3, 2),
    }

    ctr = 0.015
    cvr = 0.03
    if billing == "CPC":
        estimated_clicks = int(budget / suggested_bid)
        estimated_impressions = int(estimated_clicks / ctr)
    else:
        estimated_impressions = int(budget / suggested_bid * 1000)
        estimated_clicks = int(estimated_impressions * ctr)

    estimated_conversions = int(estimated_clicks * cvr)
    estimated_cpa = round(budget / max(estimated_conversions, 1), 2)
    estimated_cpc = round(budget / max(estimated_clicks, 1), 2)

    return {
        "budget": budget,
        "billing": billing,
        "target_cpa": target_cpa,
        "suggested_bid": suggested_bid,
        "base_bid": base,
        "hourly_bid_curve": hourly_bid,
        "estimates": {
            "impressions": estimated_impressions,
            "clicks": estimated_clicks,
            "conversions": estimated_conversions,
            "estimated_cpa": estimated_cpa,
            "estimated_cpc": estimated_cpc,
            "ctr": round(ctr, 4),
            "cvr": round(cvr, 4),
        },
        "budget_utilization": "100%",
        "note": "模拟预估，非真实投放数据。CTR/CVR 为行业假设值。",
    }


def main() -> int:
    """CLI 入口。"""
    parser = argparse.ArgumentParser(description="出价策略生成（模拟）")
    parser.add_argument("--budget", type=float, required=True, help="总预算（元）")
    parser.add_argument(
        "--billing", choices=["CPM", "CPC", "oCPM"], default="oCPM", help="计费方式"
    )
    parser.add_argument("--target-cpa", type=float, default=50.0, help="目标 CPA（元）")
    parser.add_argument("--audience-size", type=int, default=1000000, help="受众规模")
    args = parser.parse_args()

    result = generate_strategy(
        args.budget, args.billing, args.target_cpa, args.audience_size
    )
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
