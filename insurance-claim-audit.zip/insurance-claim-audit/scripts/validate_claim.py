#!/usr/bin/env python3
"""理赔单据确定性校验脚本。

在沙箱内由智能体调用，完成时效、金额、字段一致性的机械式校验，
避免让模型口算日期差与金额（K5：确定性逻辑下沉到脚本）。

用法：
    python scripts/validate_claim.py --input claim.json
    python scripts/validate_claim.py --demo

输入 JSON 结构（字段缺失即视为未提供）：
    {
      "report_no": "BX20260801001",
      "insurance_type": "property",
      "incident_date": "2026-07-20",
      "report_date": "2026-07-22",
      "claim_amount": 12800.00,
      "invoice_total": 12800.00,
      "policy_limit": 50000.00,
      "deductible": 500.00,
      "documents": ["报案单", "发票", "定损单"]
    }

输出 JSON：
    {"passed": bool, "violations": [...], "warnings": [...], "computed": {...}}
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date, datetime
from typing import Any

# 报案时效：出险后须在该天数内报案，超期触发核减/拒赔规则 R-101
# 依据：references/audit-rules.md · R-101
REPORT_DEADLINE_DAYS = 5

# 报案严重超时阈值：超过该天数直接转人工判断（R-101 补充条款）
REPORT_ESCALATION_DAYS = 30

# 金额一致性允许的误差（元），用于容忍分币进位差异
AMOUNT_TOLERANCE = 0.01

# 各险种必备材料，与 references/required-documents.md 保持同步
REQUIRED_DOCUMENTS: dict[str, tuple[str, ...]] = {
    "property": ("报案单", "发票", "定损单"),
    "health": ("报案单", "发票", "病历", "诊断证明"),
}


def _parse_date(value: str, field_name: str, violations: list[str]) -> date | None:
    """解析 YYYY-MM-DD 日期字符串。

    Args:
        value: 日期文本。
        field_name: 字段名，用于错误提示。
        violations: 违规收集列表，解析失败时追加。

    Returns:
        date | None: 解析成功返回日期，否则 None。
    """
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        violations.append(f"[R-001] 字段 {field_name} 日期格式非法（应为 YYYY-MM-DD）：{value!r}")
        return None


def _check_report_timeliness(claim: dict[str, Any], violations: list[str]) -> int | None:
    """校验报案时效。

    Args:
        claim: 理赔数据。
        violations: 违规收集列表。

    Returns:
        int | None: 报案延迟天数；无法计算时返回 None。
    """
    incident = _parse_date(claim.get("incident_date", ""), "incident_date", violations)
    reported = _parse_date(claim.get("report_date", ""), "report_date", violations)
    if incident is None or reported is None:
        return None

    delay_days = (reported - incident).days
    if delay_days < 0:
        violations.append("[R-002] 报案日期早于出险日期，数据存在矛盾。")
        return delay_days
    if delay_days > REPORT_ESCALATION_DAYS:
        violations.append(
            f"[R-101] 报案严重超时：出险后 {delay_days} 天报案，"
            f"超过 {REPORT_ESCALATION_DAYS} 天，须转人工核赔岗判断。"
        )
    elif delay_days > REPORT_DEADLINE_DAYS:
        violations.append(
            f"[R-101] 报案超时：出险后 {delay_days} 天报案，"
            f"超过规定的 {REPORT_DEADLINE_DAYS} 天，建议核减 10%。"
        )
    return delay_days


def _check_amounts(
    claim: dict[str, Any], violations: list[str], warnings: list[str]
) -> dict[str, float]:
    """校验金额一致性并计算应赔金额。

    Args:
        claim: 理赔数据。
        violations: 违规收集列表。
        warnings: 告警收集列表。

    Returns:
        dict: 计算结果，含 payable（建议赔付金额）。
    """
    computed: dict[str, float] = {}

    def _as_float(key: str, default: float = 0.0) -> float:
        """安全取浮点值。"""
        raw = claim.get(key, default)
        try:
            return round(float(raw), 2)
        except (TypeError, ValueError):
            violations.append(f"[R-003] 字段 {key} 不是合法数值：{raw!r}")
            return default

    claim_amount = _as_float("claim_amount")
    invoice_total = _as_float("invoice_total")
    policy_limit = _as_float("policy_limit")
    deductible = _as_float("deductible")

    if claim_amount <= 0:
        violations.append("[R-004] 索赔金额必须大于 0。")

    if abs(claim_amount - invoice_total) > AMOUNT_TOLERANCE:
        violations.append(
            f"[R-102] 索赔金额 {claim_amount:.2f} 与发票合计 {invoice_total:.2f} 不一致，"
            "需补正发票或调整索赔金额。"
        )

    payable = max(claim_amount - deductible, 0.0)
    if policy_limit > 0 and payable > policy_limit:
        warnings.append(
            f"[R-103] 计算赔付 {payable:.2f} 超出保额上限 {policy_limit:.2f}，"
            "已按上限核减。"
        )
        payable = policy_limit

    computed["claim_amount"] = claim_amount
    computed["deductible"] = deductible
    computed["payable"] = round(payable, 2)
    return computed


def _check_documents(
    claim: dict[str, Any], violations: list[str]
) -> list[str]:
    """校验材料完整性。

    Args:
        claim: 理赔数据。
        violations: 违规收集列表。

    Returns:
        list[str]: 缺失材料清单。
    """
    insurance_type = str(claim.get("insurance_type", "")).lower()
    required = REQUIRED_DOCUMENTS.get(insurance_type)
    if required is None:
        violations.append(
            f"[R-005] 未知险种 '{insurance_type}'，"
            f"支持的险种：{', '.join(REQUIRED_DOCUMENTS)}。"
        )
        return []

    provided = {str(item).strip() for item in claim.get("documents", [])}
    missing = [name for name in required if name not in provided]
    if missing:
        violations.append(f"[R-104] 材料缺失：{'、'.join(missing)}，需通知客户补正。")
    return missing


def validate_claim(claim: dict[str, Any]) -> dict[str, Any]:
    """执行全部校验规则。

    Args:
        claim: 理赔数据字典。

    Returns:
        dict: 校验结果，含 passed / violations / warnings / computed。
    """
    violations: list[str] = []
    warnings: list[str] = []

    if not claim.get("report_no"):
        violations.append("[R-006] 缺少报案号 report_no。")

    delay_days = _check_report_timeliness(claim, violations)
    computed = _check_amounts(claim, violations, warnings)
    missing_documents = _check_documents(claim, violations)

    if delay_days is not None:
        computed["report_delay_days"] = float(delay_days)

    return {
        "passed": not violations,
        "violations": violations,
        "warnings": warnings,
        "computed": computed,
        "missing_documents": missing_documents,
    }


_DEMO_CLAIM: dict[str, Any] = {
    "report_no": "BX20260801001",
    "insurance_type": "property",
    "incident_date": "2026-07-20",
    "report_date": "2026-07-28",
    "claim_amount": 12800.00,
    "invoice_total": 12500.00,
    "policy_limit": 50000.00,
    "deductible": 500.00,
    "documents": ["报案单", "发票"],
}


def main() -> int:
    """命令行入口。

    Returns:
        int: 进程退出码；0 表示校验通过，1 表示存在违规，2 表示输入错误。
    """
    parser = argparse.ArgumentParser(description="理赔单据确定性校验")
    parser.add_argument("--input", help="理赔数据 JSON 文件路径")
    parser.add_argument(
        "--demo", action="store_true", help="使用内置样例数据演示校验效果"
    )
    args = parser.parse_args()

    if args.demo:
        claim = _DEMO_CLAIM
    elif args.input:
        try:
            with open(args.input, encoding="utf-8") as handle:
                claim = json.load(handle)
        except (OSError, json.JSONDecodeError) as exc:
            print(json.dumps({"error": f"读取输入失败：{exc}"}, ensure_ascii=False))
            return 2
        if not isinstance(claim, dict):
            print(json.dumps({"error": "输入 JSON 必须是对象。"}, ensure_ascii=False))
            return 2
    else:
        parser.print_help()
        return 2

    result = validate_claim(claim)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
