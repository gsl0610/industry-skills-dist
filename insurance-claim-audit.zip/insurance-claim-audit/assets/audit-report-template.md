# 核赔预审意见书

**报案号**：{{report_no}}
**险种**：{{insurance_type}}
**被保险人**：{{insured_name_masked}}
**出险日期**：{{incident_date}}　**报案日期**：{{report_date}}
**预审时间**：{{audit_time}}

---

## 一、预审结论

> **{{conclusion}}**（建议赔付 / 建议核减 / 建议拒赔 / 待补材料 / 转人工）

**建议赔付金额**：人民币 {{payable_amount}} 元
（索赔金额 {{claim_amount}} 元 − 免赔额 {{deductible}} 元{{adjustment_note}}）

## 二、材料完整性

| 材料 | 状态 | 备注 |
| --- | --- | --- |
| {{document_name}} | 已提供 / 缺失 / 需补正 | {{document_note}} |

**缺件清单**：{{missing_documents}}

## 三、规则校验明细

| 规则编号 | 校验项 | 结果 | 说明 |
| --- | --- | --- | --- |
| {{rule_id}} | {{rule_name}} | 通过 / 违规 / 告警 | {{rule_detail}} |

## 四、结论依据

1. {{evidence_item}}（依据：{{evidence_source}}）

## 五、后续处理建议

- {{next_action}}

---

**免责声明**

1. 本意见书由智能体基于既有规则库与所提供材料自动生成，属**预审建议**，不构成最终理赔决定，须经人工核赔岗复核后方可生效。
2. 报告中个人敏感信息已做掩码处理。
3. 如对结论有异议，可通过 {{appeal_channel}} 提出申诉。
