# 程序化投放效果分析报告

## 一、投放概要
{campaign_summary}

## 二、渠道效果指标
{channel_metrics}

## 三、归因分析
{attribution}（模型：{model}）

## 四、漏斗分析
{funnel}

## 五、优化建议
{suggestions}

---
*由 ad-effect-attribution 技能生成，模拟数据。归因模型见 references/attribution-models.md。*
