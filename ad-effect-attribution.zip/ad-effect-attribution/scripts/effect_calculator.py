#!/usr/bin/env python3
"""广告效果指标计算与归因分析（模拟）。

仅依赖 Python 标准库。合并 effect_calculator、attribution_analyzer、funnel_analyzer。

用法：
    python3 effect_calculator.py --demo
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any

# ── Demo 数据 ──
DEMO_CHANNELS = [
    {"channel": "信息流广告", "impressions": 500000, "clicks": 7500, "conversions": 225, "spend": 15000, "revenue": 45000},
    {"channel": "搜索广告", "impressions": 200000, "clicks": 6000, "conversions": 300, "spend": 12000, "revenue": 60000},
    {"channel": "DSP投放", "impressions": 800000, "clicks": 4000, "conversions": 80, "spend": 8000, "revenue": 16000},
]

DEMO_TOUCHPOINTS = [
    {"user_id": "u1", "channel": "信息流", "position": 1, "is_conversion": 0},
    {"user_id": "u1", "channel": "搜索", "position": 2, "is_conversion": 1},
    {"user_id": "u2", "channel": "DSP", "position": 1, "is_conversion": 0},
    {"user_id": "u2", "channel": "信息流", "position": 2, "is_conversion": 0},
    {"user_id": "u2", "channel": "搜索", "position": 3, "is_conversion": 1},
    {"user_id": "u3", "channel": "信息流", "position": 1, "is_conversion": 1},
]

DEMO_FUNNEL = [
    {"stage": "曝光", "users": 1500000},
    {"stage": "点击", "users": 17500},
    {"stage": "加购", "users": 3500},
    {"stage": "下单", "users": 875},
    {"stage": "付款", "users": 605},
]


def calc_channel_metrics(row: dict[str, Any]) -> dict[str, Any]:
    """计算单渠道效果指标。"""
    imp = row["impressions"]
    clk = row["clicks"]
    conv = row["conversions"]
    spend = row["spend"]
    rev = row["revenue"]
    return {
        "channel": row["channel"],
        "ctr_percent": round(clk / imp * 100, 2) if imp else None,
        "cvr_percent": round(conv / clk * 100, 2) if clk else None,
        "cpa": round(spend / conv, 2) if conv else None,
        "roas_percent": round((rev - spend) / spend * 100, 2) if spend else None,
        "roi": round(rev / spend, 2) if spend else None,
        "spend": spend,
        "revenue": rev,
    }


def attribution(touchpoints: list[dict[str, Any]], model: str) -> dict[str, Any]:
    """多模型归因分析。"""
    channels: dict[str, float] = {}
    for tp in touchpoints:
        if tp["is_conversion"] == 1:
            user = tp["user_id"]
            user_touches = [t for t in touchpoints if t["user_id"] == user]
            if model == "first-touch":
                c = user_touches[0]["channel"]
                channels[c] = channels.get(c, 0) + 1
            elif model == "last-touch":
                conv_touch = [t for t in user_touches if t["is_conversion"] == 1][0]
                channels[conv_touch["channel"]] = channels.get(conv_touch["channel"], 0) + 1
            elif model == "linear":
                for t in user_touches:
                    channels[t["channel"]] = channels.get(t["channel"], 0) + 1 / len(user_touches)
            elif model == "time-decay":
                total = len(user_touches)
                for i, t in enumerate(user_touches):
                    weight = 2 ** (i - total + 1)
                    channels[t["channel"]] = channels.get(t["channel"], 0) + weight
    total_weight = sum(channels.values()) or 1
    return {
        "model": model,
        "channel_contributions": {k: round(v / total_weight * 100, 2) for k, v in channels.items()},
    }


def funnel_analysis(stages: list[dict[str, Any]]) -> dict[str, Any]:
    """转化漏斗分析。"""
    result = []
    for i, stage in enumerate(stages):
        entry = {"stage": stage["stage"], "users": stage["users"]}
        if i == 0:
            entry["conversion_rate_percent"] = 100.0
            entry["drop_off_percent"] = 0.0
        else:
            prev = stages[i - 1]["users"]
            entry["conversion_rate_percent"] = round(stage["users"] / prev * 100, 2) if prev else 0
            entry["drop_off_percent"] = round((1 - stage["users"] / prev) * 100, 2) if prev else 0
        result.append(entry)
    max_drop = max(result[1:], key=lambda x: x["drop_off_percent"], default=None)
    return {
        "funnel": result,
        "biggest_drop_stage": max_drop["stage"] if max_drop else None,
        "overall_conversion_percent": round(stages[-1]["users"] / stages[0]["users"] * 100, 4) if stages[0]["users"] else 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="广告效果指标计算与归因分析（模拟）")
    parser.add_argument("--model", choices=["first-touch", "last-touch", "linear", "time-decay"], default="linear")
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()

    result = {
        "channel_metrics": [calc_channel_metrics(r) for r in DEMO_CHANNELS],
        "attribution": attribution(DEMO_TOUCHPOINTS, args.model),
        "funnel": funnel_analysis(DEMO_FUNNEL),
        "note": "模拟数据，非真实投放结果。归因模型影响结论，详见 references/attribution-models.md。",
    }
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
