---
name: ad-effect-attribution
description: 当用户需要分析程序化广告投放效果、做归因分析、评估渠道贡献度、计算 ROI/ROAS、或排查转化漏斗流失原因时使用此技能。适用于信息流广告、搜索广告、DSP 投放的效果复盘与归因。
version: 1.0.0
x-industry: marketing
x-owner: marketing-team
x-compliance: internal
visibility: shared
allowedTools:
  - read_file
  - execute_command
---

# 程序化投放效果分析

## 何时使用

- 用户提供了投放数据，要求做效果复盘。
- 用户询问"哪个渠道贡献最大""ROI 怎么样""哪里流失了"。
- 用户要求做归因分析（首次触达/末次触达/线性/时间衰减）。
- 用户要求排查转化漏斗的流失环节。

不适用场景：社媒内容数据分析（用 social-media-analytics）。

## 执行步骤

1. **解析效果数据**
   提取：渠道、曝光、点击、转化、花费、转化价值。

2. **计算效果指标**
   运行 `scripts/effect_calculator.py` 计算 ROI/ROAS/CPA/CVR：
   ```bash
   python3 scripts/effect_calculator.py --input campaign_data.csv
   ```

3. **归因分析**
   运行 `scripts/attribution_analyzer.py` 做多模型归因：
   ```bash
   python3 scripts/attribution_analyzer.py --input touchpoints.csv --model multi-touch
   ```

4. **漏斗分析**
   运行 `scripts/funnel_analyzer.py` 排查流失环节：
   ```bash
   python3 scripts/funnel_analyzer.py --input funnel.csv
   ```

5. **产出效果报告**
   套用 `assets/effect-report-template.md`。

## 脚本与资源清单

| 脚本 | 用途 |
| --- | --- |
| `scripts/effect_calculator.py` | 效果指标计算（ROI/ROAS/CPA/CVR） |
| `scripts/attribution_analyzer.py` | 多模型归因（首次/末次/线性/时间衰减） |
| `scripts/funnel_analyzer.py` | 转化漏斗流失分析 |

| 资源 | 用途 |
| --- | --- |
| `references/attribution-models.md` | 归因模型定义与适用场景 |
| `references/effect-metrics.md` | 效果指标口径（ROI/ROAS/CPA 定义） |
| `assets/effect-report-template.md` | 效果分析报告模板 |

## 注意事项与边界

- 归因模型选择影响结论，须在报告中说明所用模型及其局限。
- ROI 与 ROAS 不可混用（口径见 references/effect-metrics.md）。
- 模拟数据须标注，不得作为真实投放考核依据。
