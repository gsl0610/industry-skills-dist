---
name: social-media-analytics
description: 当用户需要分析社媒运营数据、计算互动率与涨粉率等指标、做周期环比、诊断内容表现下滑原因、识别异常波动或出具社媒运营周报/月报时使用此技能。适用于抖音、小红书、视频号、B 站、微博等平台的账号与内容数据分析。
version: 1.0.0
x-industry: social-media
x-owner: growth-analytics
x-compliance: internal
allowedTools:
  - read_file
  - execute_command
---

# 社媒数据分析

## 何时使用

在以下任一情形使用本技能：

- 用户提供社媒数据（CSV / JSON / 表格文本）并要求分析表现。
- 用户询问「这周数据怎么样」「为什么互动率掉了」「哪条内容表现最好」。
- 用户要求出具社媒运营周报、月报或投放复盘。
- 用户要求识别数据异常波动或做多平台对比。

不适用场景：内容创意生成、脚本撰写、达人筛选谈判——这些请转交其他技能。

## 执行步骤

按顺序执行，不得跳步。

### 第 1 步：识别数据范围与口径

从输入中提取：平台、账号、时间范围、数据粒度（按内容 / 按天）。
若时间范围或平台不明确，先向用户追问，不要假设。

读取 `references/metric-definitions.md` 确认本次要计算的指标及其口径。

### 第 2 步：归一化数据

将用户数据整理为脚本可读的 CSV，必备列见 `assets/sample_posts.csv` 的表头。
缺失列按 0 处理，但必须在报告中标注「该指标因缺少 X 列无法计算」。

### 第 3 步：计算指标与环比（必须用脚本）

```bash
python3 scripts/analyze_metrics.py --input <数据CSV路径> --split-by platform
```

脚本输出 JSON，含 `overall`、`by_group`、`period_comparison`、`top_posts`、`bottom_posts`。

**禁止自行口算比率与环比**，所有数字一律以脚本输出为准。

### 第 4 步：识别异常波动

```bash
python3 scripts/detect_anomalies.py --input <数据CSV路径> --metric engagement_rate
```

脚本基于中位数与 MAD（绝对中位差）识别离群点，输出 `anomalies` 列表，
含日期、实际值、基准值、偏离倍数、方向（spike / drop）。

### 第 5 步：归因诊断

读取 `references/diagnosis-playbook.md`，按决策树逐层定位原因：
曝光层 → 点击层 → 互动层 → 转化层。

每条归因结论必须指明是**数据支持的结论**，还是**需要进一步验证的假设**。

### 第 6 步：对标基准

读取 `references/platform-benchmarks.md`，将本期指标与基准区间对比，
标注「高于 / 符合 / 低于」基准。

**注意**：该文件中的基准为内部示例值，若用户提供了自有历史基准，优先使用用户数据。

### 第 7 步：输出报告

套用 `assets/weekly-report-template.md` 生成报告。
每个结论必须附数据依据，每条建议必须可执行（明确动作、对象、预期指标）。

## 脚本与资源清单

| 路径 | 用途 |
| --- | --- |
| `scripts/analyze_metrics.py` | 指标计算、分组聚合、周期环比、内容排行（仅用标准库） |
| `scripts/detect_anomalies.py` | 基于 MAD 的异常波动识别（仅用标准库） |
| `references/metric-definitions.md` | 全部指标的计算口径与适用边界 |
| `references/platform-benchmarks.md` | 各平台指标基准区间（内部示例值） |
| `references/diagnosis-playbook.md` | 四层漏斗归因决策树 |
| `assets/weekly-report-template.md` | 运营周报模板 |
| `assets/sample_posts.csv` | 标准输入格式样例 |

两个脚本均只依赖 Python 标准库，无需安装第三方包。可先用 `--demo` 查看输出结构：

```bash
python3 scripts/analyze_metrics.py --demo
python3 scripts/detect_anomalies.py --demo
```

## 注意事项与边界

- **比率类指标的分母必须足够大**。曝光量低于 1000 的单条内容，其互动率波动不具统计意义，
  报告中须标注「样本量不足，仅供参考」。
- **环比需对齐周期长度**。7 天 vs 5 天的对比无效，脚本会拒绝并报错。
- **禁止编造行业基准数据**。`platform-benchmarks.md` 中的值为内部示例，
  引用时必须声明来源；用户未提供自有基准时，应明确说明「缺少可信基准，仅做内部环比」。
- **区分相关与因果**。观察到「发布时间变化 + 互动率下降」只能表述为相关，
  不得直接断言因果，需标注为待验证假设。
- **涉及达人 / 用户个人信息时做脱敏**，账号昵称可保留，真实姓名与联系方式一律掩码。
- 平台指标口径会随版本变化（如完播率定义调整），发现口径异常时应提示用户核对平台后台定义。
- 金额类指标默认人民币，出现其他币种必须显式标注。
