#!/usr/bin/env python3
"""社媒指标计算与周期环比。

在沙箱内由智能体调用，完成比率类指标、分组聚合、环比与内容排行的
确定性计算，避免让模型口算（K5：确定性逻辑下沉到脚本）。

仅依赖 Python 标准库，无需安装第三方包。

用法：
    python3 scripts/analyze_metrics.py --input posts.csv
    python3 scripts/analyze_metrics.py --input posts.csv --split-by platform
    python3 scripts/analyze_metrics.py --input posts.csv --compare-window 7
    python3 scripts/analyze_metrics.py --demo

输入 CSV 必备表头（缺失列按 0 处理）：
    date,platform,account,post_id,title,impressions,reach,likes,comments,
    shares,saves,follows,video_views,video_completions,clicks,spend

输出 JSON：
    {
      "meta": {...},
      "overall": {...},
      "by_group": {...},
      "period_comparison": {...},
      "top_posts": [...],
      "bottom_posts": [...],
      "warnings": [...]
    }
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import sys
from datetime import date, datetime, timedelta
from typing import Any

# 比率类指标的最小分母：低于该曝光量的样本，比率波动不具统计意义
MIN_IMPRESSIONS_FOR_RATE = 1000

# 排行榜默认条数
DEFAULT_RANK_SIZE = 5

# 数值型列，读取时统一转 float
NUMERIC_COLUMNS: tuple[str, ...] = (
    "impressions",
    "reach",
    "likes",
    "comments",
    "shares",
    "saves",
    "follows",
    "video_views",
    "video_completions",
    "clicks",
    "spend",
)

# 文本型列
TEXT_COLUMNS: tuple[str, ...] = ("date", "platform", "account", "post_id", "title")


def _safe_divide(numerator: float, denominator: float, *, scale: float = 1.0) -> float | None:
    """安全除法，分母为 0 时返回 None 而非抛错。

    Args:
        numerator: 分子。
        denominator: 分母。
        scale: 结果缩放系数（如百分比传 100，CPM 传 1000）。

    Returns:
        float | None: 计算结果保留 4 位小数；分母为 0 时返回 None。
    """
    if not denominator:
        return None
    return round(numerator / denominator * scale, 4)


def _parse_date(value: str) -> date | None:
    """解析日期，支持 YYYY-MM-DD 与 YYYY/MM/DD。

    Args:
        value: 日期文本。

    Returns:
        date | None: 解析失败返回 None。
    """
    for pattern in ("%Y-%m-%d", "%Y/%m/%d", "%Y%m%d"):
        try:
            return datetime.strptime(value.strip(), pattern).date()
        except (TypeError, ValueError):
            continue
    return None


def load_rows(raw_text: str) -> tuple[list[dict[str, Any]], list[str]]:
    """解析 CSV 文本为归一化的数据行。

    Args:
        raw_text: CSV 全文。

    Returns:
        tuple: (数据行列表, 警告信息列表)。
    """
    warnings: list[str] = []
    reader = csv.DictReader(io.StringIO(raw_text))
    if reader.fieldnames is None:
        return [], ["CSV 缺少表头，无法解析。"]

    present = {name.strip() for name in reader.fieldnames}
    missing_numeric = [col for col in NUMERIC_COLUMNS if col not in present]
    if missing_numeric:
        warnings.append(
            f"缺少数值列 {missing_numeric}，相关指标按 0 计算，请在报告中标注不可用。"
        )
    if "date" not in present:
        warnings.append("缺少 date 列，无法进行周期环比与异常检测。")

    rows: list[dict[str, Any]] = []
    for line_number, raw_row in enumerate(reader, start=2):
        row: dict[str, Any] = {}
        for column in TEXT_COLUMNS:
            row[column] = (raw_row.get(column) or "").strip()
        for column in NUMERIC_COLUMNS:
            raw_value = (raw_row.get(column) or "").strip().replace(",", "")
            try:
                row[column] = float(raw_value) if raw_value else 0.0
            except ValueError:
                warnings.append(
                    f"第 {line_number} 行的 {column} 不是合法数值（{raw_value!r}），已按 0 处理。"
                )
                row[column] = 0.0
        row["_date"] = _parse_date(row["date"]) if row["date"] else None
        rows.append(row)

    return rows, warnings


def _aggregate(rows: list[dict[str, Any]]) -> dict[str, float]:
    """按列求和。

    Args:
        rows: 数据行。

    Returns:
        dict: 各数值列的总和。
    """
    totals = {column: 0.0 for column in NUMERIC_COLUMNS}
    for row in rows:
        for column in NUMERIC_COLUMNS:
            totals[column] += float(row.get(column) or 0.0)
    return totals


def compute_metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """计算一组数据的全部指标。

    指标口径见 references/metric-definitions.md。

    Args:
        rows: 数据行。

    Returns:
        dict: 含 totals（绝对量）与 rates（比率，单位 %）。
    """
    totals = _aggregate(rows)
    interactions = (
        totals["likes"] + totals["comments"] + totals["shares"] + totals["saves"]
    )
    totals["interactions"] = interactions
    totals["post_count"] = float(len(rows))

    rates: dict[str, float | None] = {
        # 互动率：以曝光为分母，衡量内容的综合吸引力
        "engagement_rate_by_impressions": _safe_divide(
            interactions, totals["impressions"], scale=100
        ),
        # 互动率：以触达为分母，排除重复曝光影响，更贴近真实人群反馈
        "engagement_rate_by_reach": _safe_divide(
            interactions, totals["reach"], scale=100
        ),
        "like_rate": _safe_divide(totals["likes"], totals["impressions"], scale=100),
        "comment_rate": _safe_divide(
            totals["comments"], totals["impressions"], scale=100
        ),
        "share_rate": _safe_divide(totals["shares"], totals["impressions"], scale=100),
        "save_rate": _safe_divide(totals["saves"], totals["impressions"], scale=100),
        # 涨粉率：以触达为分母，衡量内容的转粉效率
        "follow_rate": _safe_divide(totals["follows"], totals["reach"], scale=100),
        "ctr": _safe_divide(totals["clicks"], totals["impressions"], scale=100),
        # 完播率：仅视频内容有效
        "completion_rate": _safe_divide(
            totals["video_completions"], totals["video_views"], scale=100
        ),
        # CPM：千次曝光成本
        "cpm": _safe_divide(totals["spend"], totals["impressions"], scale=1000),
        # CPE：单次互动成本
        "cpe": _safe_divide(totals["spend"], interactions),
        # CPF：单个新增粉丝成本
        "cpf": _safe_divide(totals["spend"], totals["follows"]),
    }

    return {
        "totals": {key: round(value, 2) for key, value in totals.items()},
        "rates_percent_or_currency": rates,
        "rate_reliable": totals["impressions"] >= MIN_IMPRESSIONS_FOR_RATE,
    }


def _post_engagement_rate(row: dict[str, Any]) -> float:
    """计算单条内容的互动率，用于排行。

    Args:
        row: 单条数据行。

    Returns:
        float: 互动率（%）；曝光为 0 时返回 -1 以排到末尾。
    """
    impressions = float(row.get("impressions") or 0.0)
    if impressions <= 0:
        return -1.0
    interactions = sum(
        float(row.get(key) or 0.0) for key in ("likes", "comments", "shares", "saves")
    )
    return round(interactions / impressions * 100, 4)


def rank_posts(
    rows: list[dict[str, Any]], *, size: int = DEFAULT_RANK_SIZE
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """按互动率对内容排行。

    Args:
        rows: 数据行。
        size: 榜单条数。

    Returns:
        tuple: (top 榜, bottom 榜)。
    """
    scored = [
        {
            "post_id": row.get("post_id"),
            "title": row.get("title"),
            "platform": row.get("platform"),
            "date": row.get("date"),
            "impressions": round(float(row.get("impressions") or 0.0), 2),
            "engagement_rate_percent": _post_engagement_rate(row),
            "sample_sufficient": float(row.get("impressions") or 0.0)
            >= MIN_IMPRESSIONS_FOR_RATE,
        }
        for row in rows
    ]
    # 仅在样本充足的内容中排行，避免小曝光高互动率误导决策
    reliable = [item for item in scored if item["sample_sufficient"]]
    pool = reliable or scored
    ordered = sorted(pool, key=lambda item: item["engagement_rate_percent"], reverse=True)
    return ordered[:size], list(reversed(ordered[-size:]))


def compare_periods(
    rows: list[dict[str, Any]], window_days: int | None
) -> dict[str, Any]:
    """计算周期环比。

    以数据中的最大日期为基准，取最近 window_days 为本期，
    紧邻的等长区间为上期。

    Args:
        rows: 数据行。
        window_days: 本期天数；None 时自动取数据跨度的一半。

    Returns:
        dict: 含本期/上期指标与各比率的变化值。
    """
    dated = [row for row in rows if row.get("_date") is not None]
    if not dated:
        return {"available": False, "reason": "数据缺少可解析的 date 列。"}

    latest: date = max(row["_date"] for row in dated)
    earliest: date = min(row["_date"] for row in dated)
    span_days = (latest - earliest).days + 1

    if window_days is None:
        window_days = span_days // 2
    if window_days <= 0:
        return {
            "available": False,
            "reason": f"数据跨度仅 {span_days} 天，不足以拆分为两个周期。",
        }
    if span_days < window_days * 2:
        return {
            "available": False,
            "reason": (
                f"数据跨度 {span_days} 天，不足以支撑 {window_days} 天的等长环比"
                f"（需至少 {window_days * 2} 天）。"
            ),
        }

    current_start = latest - timedelta(days=window_days - 1)
    previous_end = current_start - timedelta(days=1)
    previous_start = previous_end - timedelta(days=window_days - 1)

    current_rows = [row for row in dated if current_start <= row["_date"] <= latest]
    previous_rows = [
        row for row in dated if previous_start <= row["_date"] <= previous_end
    ]

    current = compute_metrics(current_rows)
    previous = compute_metrics(previous_rows)

    changes: dict[str, Any] = {}
    for key, current_value in current["rates_percent_or_currency"].items():
        previous_value = previous["rates_percent_or_currency"].get(key)
        if current_value is None or previous_value is None:
            changes[key] = None
            continue
        absolute = round(current_value - previous_value, 4)
        relative = (
            round((current_value - previous_value) / previous_value * 100, 2)
            if previous_value
            else None
        )
        changes[key] = {
            "current": current_value,
            "previous": previous_value,
            "absolute_change": absolute,
            "relative_change_percent": relative,
        }

    return {
        "available": True,
        "window_days": window_days,
        "current_period": f"{current_start.isoformat()} ~ {latest.isoformat()}",
        "previous_period": f"{previous_start.isoformat()} ~ {previous_end.isoformat()}",
        "current_metrics": current,
        "previous_metrics": previous,
        "rate_changes": changes,
    }


def analyze(
    rows: list[dict[str, Any]],
    *,
    split_by: str | None,
    compare_window: int | None,
    rank_size: int,
) -> dict[str, Any]:
    """执行完整分析。

    Args:
        rows: 数据行。
        split_by: 分组维度列名（如 platform / account）。
        compare_window: 环比窗口天数。
        rank_size: 榜单条数。

    Returns:
        dict: 分析结果。
    """
    dates = [row["_date"] for row in rows if row.get("_date")]
    top_posts, bottom_posts = rank_posts(rows, size=rank_size)

    by_group: dict[str, Any] = {}
    if split_by:
        buckets: dict[str, list[dict[str, Any]]] = {}
        for row in rows:
            key = str(row.get(split_by) or "未标注")
            buckets.setdefault(key, []).append(row)
        by_group = {key: compute_metrics(value) for key, value in sorted(buckets.items())}

    return {
        "meta": {
            "row_count": len(rows),
            "date_range": (
                f"{min(dates).isoformat()} ~ {max(dates).isoformat()}" if dates else None
            ),
            "split_by": split_by,
            "min_impressions_for_reliable_rate": MIN_IMPRESSIONS_FOR_RATE,
        },
        "overall": compute_metrics(rows),
        "by_group": by_group,
        "period_comparison": compare_periods(rows, compare_window),
        "top_posts": top_posts,
        "bottom_posts": bottom_posts,
    }


DEMO_CSV = """date,platform,account,post_id,title,impressions,reach,likes,comments,shares,saves,follows,video_views,video_completions,clicks,spend
2026-07-14,douyin,brandA,d001,夏日穿搭第一弹,120000,98000,4200,310,860,1500,420,115000,42000,2100,3000
2026-07-15,douyin,brandA,d002,通勤包测评,86000,72000,2100,140,300,620,150,82000,24000,900,2000
2026-07-16,xiaohongshu,brandA,x001,平价好物清单,45000,39000,3100,420,510,2600,380,0,0,1500,1200
2026-07-17,xiaohongshu,brandA,x002,办公室穿搭,32000,28000,1200,90,120,700,110,0,0,600,800
2026-07-18,douyin,brandA,d003,工厂溯源vlog,210000,175000,9800,1200,3400,4100,1600,205000,96000,5200,5000
2026-07-19,xiaohongshu,brandA,x003,材质科普,28000,25000,900,150,180,1100,95,0,0,520,600
2026-07-20,douyin,brandA,d004,直播切片,64000,55000,1300,80,150,340,90,61000,12000,700,1500
2026-07-21,douyin,brandA,d005,新品预告,98000,84000,2600,190,420,880,260,94000,31000,1400,2500
2026-07-22,xiaohongshu,brandA,x004,搭配公式,52000,46000,3400,510,620,3100,450,0,0,1800,1300
2026-07-23,douyin,brandA,d006,用户返图合集,74000,63000,1800,120,260,600,170,71000,19000,880,1800
2026-07-24,xiaohongshu,brandA,x005,收纳技巧,30000,27000,1000,110,140,820,100,0,0,540,700
2026-07-25,douyin,brandA,d007,幕后花絮,58000,50000,1100,70,130,300,80,55000,10000,600,1400
2026-07-26,douyin,brandA,d008,促销倒计时,132000,110000,2900,210,480,900,300,126000,33000,2600,4200
2026-07-27,xiaohongshu,brandA,x006,尺码指南,26000,23000,700,80,90,520,70,0,0,430,500
"""


def main() -> int:
    """CLI 入口。

    Returns:
        int: 退出码；0 成功，2 输入错误。
    """
    parser = argparse.ArgumentParser(description="社媒指标计算与周期环比")
    parser.add_argument("--input", help="数据 CSV 路径")
    parser.add_argument("--demo", action="store_true", help="使用内置样例数据")
    parser.add_argument(
        "--split-by", help="分组维度列名，如 platform / account", default=None
    )
    parser.add_argument(
        "--compare-window",
        type=int,
        default=None,
        help="环比窗口天数；缺省时自动取数据跨度一半",
    )
    parser.add_argument(
        "--rank-size", type=int, default=DEFAULT_RANK_SIZE, help="榜单条数"
    )
    args = parser.parse_args()

    if args.demo:
        raw_text = DEMO_CSV
    elif args.input:
        try:
            with open(args.input, encoding="utf-8-sig") as handle:
                raw_text = handle.read()
        except OSError as exc:
            print(json.dumps({"error": f"读取输入失败：{exc}"}, ensure_ascii=False))
            return 2
    else:
        parser.print_help()
        return 2

    rows, warnings = load_rows(raw_text)
    if not rows:
        print(
            json.dumps(
                {"error": "未解析到任何数据行。", "warnings": warnings},
                ensure_ascii=False,
            )
        )
        return 2

    result = analyze(
        rows,
        split_by=args.split_by,
        compare_window=args.compare_window,
        rank_size=args.rank_size,
    )
    result["warnings"] = warnings
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
