#!/usr/bin/env python3
"""社媒数据异常波动检测。

基于中位数与 MAD（Median Absolute Deviation，绝对中位差）识别离群点。
相比均值加标准差，MAD 对极端值更稳健，适合社媒数据这类偶发爆款场景。

仅依赖 Python 标准库。

用法：
    python3 scripts/detect_anomalies.py --input posts.csv
    python3 scripts/detect_anomalies.py --input posts.csv --metric impressions
    python3 scripts/detect_anomalies.py --input posts.csv --threshold 2.5
    python3 scripts/detect_anomalies.py --demo

输出 JSON：
    {
      "meta": {...},
      "baseline": {"median": ..., "mad": ...},
      "series": [...],
      "anomalies": [...]
    }
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from analyze_metrics import DEMO_CSV, load_rows  # noqa: E402

# 偏离阈值：|value - median| / MAD 超过该倍数即判定异常
DEFAULT_THRESHOLD = 3.0

# 最少样本数，低于该值不做异常判定（统计意义不足）
MIN_SAMPLE_SIZE = 5

# MAD 转换为标准差的一致性常数（正态分布下 1/0.6745）
MAD_TO_SIGMA = 1.4826

# 支持检测的指标及其计算方式
SUPPORTED_METRICS: tuple[str, ...] = (
    "engagement_rate",
    "impressions",
    "reach",
    "follows",
    "interactions",
    "completion_rate",
    "cpm",
)


def _metric_value(row: dict[str, Any], metric: str) -> float | None:
    """计算单行的指标值。

    Args:
        row: 数据行。
        metric: 指标名。

    Returns:
        float | None: 指标值；无法计算时返回 None。
    """
    impressions = float(row.get("impressions") or 0.0)
    interactions = sum(
        float(row.get(key) or 0.0) for key in ("likes", "comments", "shares", "saves")
    )

    if metric == "engagement_rate":
        return round(interactions / impressions * 100, 4) if impressions else None
    if metric == "interactions":
        return interactions
    if metric == "completion_rate":
        views = float(row.get("video_views") or 0.0)
        completions = float(row.get("video_completions") or 0.0)
        return round(completions / views * 100, 4) if views else None
    if metric == "cpm":
        spend = float(row.get("spend") or 0.0)
        return round(spend / impressions * 1000, 4) if impressions else None
    value = row.get(metric)
    return float(value) if value is not None else None


def _aggregate_by_date(
    rows: list[dict[str, Any]], metric: str
) -> list[dict[str, Any]]:
    """按日期聚合后计算指标，避免同日多条内容互相干扰。

    Args:
        rows: 数据行。
        metric: 指标名。

    Returns:
        list[dict]: 按日期升序的序列，含 date、value、post_count。
    """
    buckets: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        day = row.get("date") or ""
        if not day:
            continue
        buckets.setdefault(day, []).append(row)

    series: list[dict[str, Any]] = []
    for day in sorted(buckets):
        day_rows = buckets[day]
        # 聚合口径：先把当日各列求和，再按聚合值算比率，避免比率的算术平均偏差
        merged: dict[str, Any] = {}
        for column in (
            "impressions",
            "reach",
            "likes",
            "comments",
            "shares",
            "saves",
            "follows",
            "video_views",
            "video_completions",
            "clicks",
            "spend",
        ):
            merged[column] = sum(float(item.get(column) or 0.0) for item in day_rows)
        value = _metric_value(merged, metric)
        if value is None:
            continue
        series.append(
            {"date": day, "value": value, "post_count": len(day_rows)}
        )
    return series


def detect(
    series: list[dict[str, Any]], *, threshold: float
) -> tuple[dict[str, float], list[dict[str, Any]]]:
    """基于 MAD 识别离群点。

    Args:
        series: 时间序列。
        threshold: 偏离倍数阈值。

    Returns:
        tuple: (基准信息, 异常列表)。
    """
    values = [item["value"] for item in series]
    median = statistics.median(values)
    deviations = [abs(value - median) for value in values]
    mad = statistics.median(deviations)

    # MAD 为 0 表示半数以上取值完全相同，退化为用平均绝对偏差兜底
    effective_mad = mad if mad > 0 else (statistics.mean(deviations) or 0.0)

    baseline = {
        "median": round(median, 4),
        "mad": round(mad, 4),
        "effective_mad": round(effective_mad, 4),
        "robust_sigma": round(effective_mad * MAD_TO_SIGMA, 4),
    }

    anomalies: list[dict[str, Any]] = []
    if effective_mad <= 0:
        return baseline, anomalies

    for item in series:
        deviation_ratio = abs(item["value"] - median) / effective_mad
        if deviation_ratio < threshold:
            continue
        anomalies.append(
            {
                "date": item["date"],
                "value": item["value"],
                "baseline_median": baseline["median"],
                "deviation_ratio": round(deviation_ratio, 2),
                "direction": "spike" if item["value"] > median else "drop",
                "post_count": item["post_count"],
            }
        )
    return baseline, anomalies


def main() -> int:
    """CLI 入口。

    Returns:
        int: 退出码；0 无异常，1 检出异常，2 输入错误。
    """
    parser = argparse.ArgumentParser(description="社媒数据异常波动检测")
    parser.add_argument("--input", help="数据 CSV 路径")
    parser.add_argument("--demo", action="store_true", help="使用内置样例数据")
    parser.add_argument(
        "--metric",
        default="engagement_rate",
        choices=SUPPORTED_METRICS,
        help="待检测指标",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=DEFAULT_THRESHOLD,
        help="偏离倍数阈值，越小越敏感",
    )
    args = parser.parse_args()

    if args.demo:
        raw_text = DEMO_CSV
    elif args.input:
        try:
            with open(args.input, encoding="utf-8-sig") as handle:
                raw_text = handle.read()
        except OSError as exc:
            print(json.dumps({"error": f"读取输入失败：{exc}"}, ensure_ascii=False))
            return 2
    else:
        parser.print_help()
        return 2

    rows, warnings = load_rows(raw_text)
    series = _aggregate_by_date(rows, args.metric)

    if len(series) < MIN_SAMPLE_SIZE:
        print(
            json.dumps(
                {
                    "error": (
                        f"有效样本仅 {len(series)} 天，少于 {MIN_SAMPLE_SIZE} 天，"
                        "不足以进行异常判定。"
                    ),
                    "warnings": warnings,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 2

    baseline, anomalies = detect(series, threshold=args.threshold)
    print(
        json.dumps(
            {
                "meta": {
                    "metric": args.metric,
                    "threshold": args.threshold,
                    "sample_days": len(series),
                    "method": "median + MAD（对极端值稳健）",
                },
                "baseline": baseline,
                "series": series,
                "anomalies": anomalies,
                "warnings": warnings,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 1 if anomalies else 0


if __name__ == "__main__":
    sys.exit(main())
