# 社媒运营周报

**账号**：{{account}}　**平台**：{{platforms}}
**统计周期**：{{current_period}}（对比周期：{{previous_period}}）
**生成时间**：{{generated_at}}

---

## 一、本期概览

| 指标 | 本期 | 上期 | 环比 | 对标基准 |
| --- | --- | --- | --- | --- |
| 曝光量 | {{impressions}} | {{prev_impressions}} | {{impressions_change}} | — |
| 触达量 | {{reach}} | {{prev_reach}} | {{reach_change}} | — |
| 互动总量 | {{interactions}} | {{prev_interactions}} | {{interactions_change}} | — |
| 互动率 | {{engagement_rate}}% | {{prev_engagement_rate}}% | {{engagement_rate_change}} | {{engagement_benchmark}} |
| 涨粉率 | {{follow_rate}}% | {{prev_follow_rate}}% | {{follow_rate_change}} | {{follow_benchmark}} |
| 新增关注 | {{follows}} | {{prev_follows}} | {{follows_change}} | — |
| CPM | ¥{{cpm}} | ¥{{prev_cpm}} | {{cpm_change}} | {{cpm_benchmark}} |
| 发布条数 | {{post_count}} | {{prev_post_count}} | {{post_count_change}} | — |

**一句话结论**：{{headline_conclusion}}

> 数据来源：`analyze_metrics.py` 确定性计算输出。
> 对标基准来源：{{benchmark_source}}

## 二、分平台表现

| 平台 | 曝光 | 互动率 | 涨粉率 | CPM | 判定 |
| --- | --- | --- | --- | --- | --- |
| {{platform_name}} | {{p_impressions}} | {{p_engagement_rate}}% | {{p_follow_rate}}% | ¥{{p_cpm}} | {{p_verdict}} |

## 三、内容排行

### 表现最佳

| 排名 | 内容 | 平台 | 曝光 | 互动率 | 关键特征 |
| --- | --- | --- | --- | --- | --- |
| 1 | {{top_title}} | {{top_platform}} | {{top_impressions}} | {{top_rate}}% | {{top_insight}} |

### 表现最弱

| 排名 | 内容 | 平台 | 曝光 | 互动率 | 可能原因 |
| --- | --- | --- | --- | --- | --- |
| 1 | {{bottom_title}} | {{bottom_platform}} | {{bottom_impressions}} | {{bottom_rate}}% | {{bottom_reason}} |

> 排行仅纳入曝光 ≥ 1000 的内容，避免小样本高比率误导。

## 四、异常波动

| 日期 | 指标 | 实际值 | 基准中位数 | 偏离倍数 | 方向 | 说明 |
| --- | --- | --- | --- | --- | --- | --- |
| {{anomaly_date}} | {{anomaly_metric}} | {{anomaly_value}} | {{anomaly_baseline}} | {{anomaly_ratio}}× | {{anomaly_direction}} | {{anomaly_note}} |

> 检测方法：中位数 + MAD（对极端值稳健），阈值 {{anomaly_threshold}}×。

## 五、归因分析

按四层漏斗自上而下定位（依据 `references/diagnosis-playbook.md`）：

### ① 曝光层
{{funnel_impression}}

### ② 点击层
{{funnel_click}}

### ③ 互动层
{{funnel_engagement}}

### ④ 转化层
{{funnel_conversion}}

### 结论分类

| 类别 | 内容 |
| --- | --- |
| **数据可验证结论** | {{verified_conclusions}} |
| **需验证假设** | {{hypotheses_to_verify}}（验证方法：{{verification_method}}） |
| **相关非因果** | {{correlation_only}} |

## 六、下周行动建议

每条建议含「具体动作 + 明确对象 + 预期指标」三要素：

| # | 动作 | 对象 | 预期指标变化 | 依据 |
| --- | --- | --- | --- | --- |
| 1 | {{action}} | {{action_target}} | {{expected_metric}} | {{action_evidence}} |

## 七、需人工确认事项

以下问题数据无法回答，需人工核查：

- {{manual_check_item}}

---

**说明**

1. 本报告由智能体基于所提供数据自动生成，全部比率与环比均来自脚本确定性计算。
2. 标注「待验证」的内容为假设，未经数据证实，不可直接作为决策依据。
3. 跨平台指标口径不同，平台间仅做趋势对比，不做绝对值对比。
4. 涉及个人信息的字段已做脱敏处理。
