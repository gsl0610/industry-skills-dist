#!/usr/bin/env python3
"""直播脚本规划与流量预估（模拟）。

仅依赖 Python 标准库。合并 livestream_planner 与 reach_estimator 功能。

用法：
    python3 livestream_planner.py --product "保温杯" --duration 120 --target-gmv 50000
    python3 livestream_planner.py --demo
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any

PHASE_RATIOS = [
    ("开场", 0.05, "暖场造势，吸引停留"),
    ("产品讲解", 0.40, "核心卖点输出，建立信任"),
    ("互动", 0.15, "提升活跃度与停留时长"),
    ("逼单", 0.25, "制造紧迫感，推动成交"),
    ("返场", 0.15, "二次触达，回收犹豫用户"),
]

PLATFORM_BASE = {
    "douyin": {"view_rate": 0.08, "peak_rate": 0.35, "interact_rate": 0.05, "conv_rate": 0.015},
    "video号": {"view_rate": 0.05, "peak_rate": 0.30, "interact_rate": 0.04, "conv_rate": 0.012},
    "xiaohongshu": {"view_rate": 0.03, "peak_rate": 0.25, "interact_rate": 0.06, "conv_rate": 0.008},
}


def plan_livestream(product: str, duration: int, target_gmv: float) -> dict[str, Any]:
    """生成直播流程脚本。"""
    phases = []
    elapsed = 0
    for name, ratio, purpose in PHASE_RATIOS:
        minutes = round(duration * ratio)
        phases.append({
            "phase": name,
            "duration_minutes": minutes,
            "start_minute": elapsed,
            "purpose": purpose,
        })
        elapsed += minutes
    return {
        "product": product,
        "total_duration": duration,
        "target_gmv": target_gmv,
        "phases": phases,
        "product_slots": [
            {"slot": "引流款", "role": "低价拉人气", "timing": "开场"},
            {"slot": "爆款", "role": "核心利润款", "timing": "产品讲解前段"},
            {"slot": "搭配款", "role": "提升客单价", "timing": "产品讲解后段"},
            {"slot": "利润款", "role": "逼单主推", "timing": "逼单"},
            {"slot": "清仓款", "role": "返场福利", "timing": "返场"},
        ],
    }


def estimate_reach(platform: str, duration: int, budget: float, followers: int) -> dict[str, Any]:
    """预估流量与互动。"""
    base = PLATFORM_BASE.get(platform, PLATFORM_BASE["douyin"])
    views = int(followers * base["view_rate"] * (1 + budget / 10000))
    peak = int(views * base["peak_rate"])
    interactions = int(views * base["interact_rate"])
    conversions = int(views * base["conv_rate"])
    return {
        "platform": platform,
        "followers": followers,
        "estimated_views": views,
        "peak_concurrent": peak,
        "estimated_interactions": interactions,
        "estimated_conversions": conversions,
        "interact_rate_percent": round(base["interact_rate"] * 100, 2),
        "conv_rate_percent": round(base["conv_rate"] * 100, 2),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="直播脚本规划与流量预估（模拟）")
    parser.add_argument("--product", default="保温杯")
    parser.add_argument("--duration", type=int, default=120)
    parser.add_argument("--target-gmv", type=float, default=50000)
    parser.add_argument("--platform", default="douyin")
    parser.add_argument("--budget", type=float, default=5000)
    parser.add_argument("--followers", type=int, default=50000)
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()

    result = {
        "livestream_plan": plan_livestream(args.product, args.duration, args.target_gmv),
        "reach_estimate": estimate_reach(args.platform, args.duration, args.budget, args.followers),
        "note": "模拟数据，非真实直播数据。流量预估基于平台基准系数。",
    }
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
