---
name: livestream-social-reach
description: 当用户需要规划直播营销方案、制定社媒触达策略、配置直播脚本、评估直播流量与互动指标、或做虚拟直播/点播转码方案设计时使用此技能。适用于品牌自播、达人直播、虚拟主播、社媒矩阵分发等场景。
version: 1.0.0
x-industry: marketing
x-owner: marketing-team
x-compliance: internal
visibility: internal
allowedTools:
  - read_file
  - execute_command
---

# 直播及社媒营销触达

## 何时使用

在以下任一情形使用本技能：

- 用户要求制定直播营销方案（时长、脚本、排品、互动机制）。
- 用户询问"直播怎么做""社媒怎么触达""流量怎么分配"。
- 用户要求评估直播预估流量、互动率、GMV 转化。
- 用户要求设计虚拟直播或点播转码方案。

不适用场景：素材制作（用 creative-generation）、广告投放出价（用 programmatic-bidding）。

## 执行步骤

按顺序执行，不得跳步：

1. **解析触达需求**
   从用户输入提取：直播/社媒、品牌、产品、目标（带货/种草/品宣）、
   平台（抖音/视频号/小红书）、预算与时长。关键字段缺失时先追问。

2. **制定直播脚本**
   运行 `scripts/livestream_planner.py` 生成直播方案：
   - 输入：产品、时长、目标 GMV
   - 输出：直播流程脚本（开场/产品讲解/互动/逼单/返场）+ 排品顺序 + 话术要点

   ```bash
   python3 scripts/livestream_planner.py --product "保温杯" --duration 120 --target-gmv 50000
   ```

3. **流量预估**
   运行 `scripts/reach_estimator.py` 估算流量与互动：
   - 输入：平台、时长、预算、粉丝基数
   - 输出：预估观看人数、峰值在线、互动率、预估转化

   ```bash
   python3 scripts/reach_estimator.py --platform douyin --duration 120 --budget 5000 --followers 50000
   ```

4. **社媒矩阵分发方案**
   依据 `references/social-matrix-playbook.md` 的分发策略，
   输出多平台分发计划（主阵地+同步分发+二次创作）。

5. **产出触达方案**
   套用 `assets/reach-plan-template.md` 输出完整方案。

## 脚本与资源清单

### scripts/livestream_planner.py — 直播脚本规划（模拟）

根据产品与时长生成直播流程脚本与排品顺序。仅依赖标准库。

### scripts/reach_estimator.py — 流量预估（模拟）

基于平台基准与粉丝基数预估观看、互动、转化。仅依赖标准库。

### 参考资料与模板

| 资源 | 用途 |
| --- | --- |
| `references/livestream-playbook.md` | 直播脚本框架与话术规范 |
| `references/social-matrix-playbook.md` | 社媒矩阵分发策略 |
| `references/platform-benchmarks.md` | 各平台流量与互动基准 |
| `assets/reach-plan-template.md` | 触达方案模板 |

## 注意事项与边界

- **全部模拟**：流量与转化预估为模拟值，须标注"模拟数据"。
- **平台差异**：各平台流量机制不同，须按 `references/platform-benchmarks.md` 分别预估。
- **合规提示**：直播带货须符合《网络直播营销管理办法》，须提示"不得虚假宣传"。
- **不保证 GMV**：预估转化为模拟值，不得表述为"保证成交"。
