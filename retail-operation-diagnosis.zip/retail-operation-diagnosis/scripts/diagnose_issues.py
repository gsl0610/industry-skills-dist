#!/usr/bin/env python3
"""零售经营异常排查：规则引擎 + MAD 异常检测。

仅依赖 Python 标准库。
规则编号与 references/benchmarks.md 的基准区间一一对应。

用法：
    python3 diagnose_issues.py --input daily.csv [--mad-threshold 3.0]
    python3 diagnose_issues.py --demo
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
from collections import defaultdict
from typing import Any

# 与 analyze_operations 共享数据加载逻辑（同目录脚本）
from analyze_operations import build_demo_rows, load_rows, split_periods

# ── 基准阈值（出处：references/benchmarks.md）────────────────
# 动销率下限：低于该值说明 SKU 结构存在问题（B-SELLTHROUGH）
SELL_THROUGH_FLOOR_PERCENT = 70.0
# 库存周转天数上限：超过则判定库存积压（B-INVENTORY）
INVENTORY_TURNOVER_CEILING_DAYS = 75.0
# 转化率环比降幅阈值：超过该幅度判为异常（B-CONVERSION）
CONVERSION_DROP_PERCENT = 20.0
# 客单价环比降幅阈值（B-ATV）
ATV_DROP_PERCENT = 10.0
# 毛利率下限（B-MARGIN，综合零售）
GROSS_MARGIN_FLOOR_PERCENT = 25.0
# MAD 异常检测最小样本天数
MIN_BASELINE_DAYS = 7


def check_indicator_rules(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """基于指标规则的异常检查。

    Args:
        rows: 合法数据行。

    Returns:
        list: 命中的规则问题列表。
    """
    issues: list[dict[str, Any]] = []
    previous, current = split_periods(rows)
    if not previous or not current:
        return issues

    def rate(part: list[dict[str, Any]], num: str, den: str) -> float:
        denominator = sum(r[den] for r in part)
        return sum(r[num] for r in part) / denominator if denominator else 0.0

    prev_conv = rate(previous, "orders", "visitors")
    curr_conv = rate(current, "orders", "visitors")
    if prev_conv > 0:
        conv_drop = (prev_conv - curr_conv) / prev_conv * 100
        if conv_drop > CONVERSION_DROP_PERCENT:
            issues.append({
                "rule_id": "B-CONVERSION",
                "severity": "high",
                "title": "转化率显著下滑",
                "evidence": (
                    f"转化率由 {prev_conv * 100:.2f}% 降至 {curr_conv * 100:.2f}%，"
                    f"降幅 {conv_drop:.1f}%（阈值 {CONVERSION_DROP_PERCENT}%）"
                ),
                "suggestion": "排查流量来源结构变化、落地页/陈列调整、竞品促销动作",
            })

    prev_atv = rate(previous, "gmv", "orders")
    curr_atv = rate(current, "gmv", "orders")
    if prev_atv > 0:
        atv_drop = (prev_atv - curr_atv) / prev_atv * 100
        if atv_drop > ATV_DROP_PERCENT:
            issues.append({
                "rule_id": "B-ATV",
                "severity": "medium",
                "title": "客单价下滑",
                "evidence": (
                    f"客单价由 {prev_atv:.2f} 降至 {curr_atv:.2f}，"
                    f"降幅 {atv_drop:.1f}%（阈值 {ATV_DROP_PERCENT}%）"
                ),
                "suggestion": "检查促销折扣深度、高价品缺货、连带销售执行情况",
            })

    total_sold = sum(r["sku_sold"] for r in rows)
    total_sku = sum(r["sku_total"] for r in rows)
    if total_sku > 0:
        sell_through = total_sold / total_sku * 100
        if sell_through < SELL_THROUGH_FLOOR_PERCENT:
            issues.append({
                "rule_id": "B-SELLTHROUGH",
                "severity": "medium",
                "title": "动销率低于健康线",
                "evidence": (
                    f"动销率 {sell_through:.1f}%，"
                    f"低于 {SELL_THROUGH_FLOOR_PERCENT}% 健康线"
                ),
                "suggestion": "梳理滞销 SKU 清单，评估清仓/调拨/汰换方案",
            })

    total_gmv = sum(r["gmv"] for r in rows)
    total_cost = sum(r["cost"] for r in rows)
    if total_gmv > 0:
        margin = (total_gmv - total_cost) / total_gmv * 100
        if margin < GROSS_MARGIN_FLOOR_PERCENT:
            issues.append({
                "rule_id": "B-MARGIN",
                "severity": "high",
                "title": "毛利率低于下限",
                "evidence": f"综合毛利率 {margin:.1f}%，低于 {GROSS_MARGIN_FLOOR_PERCENT}%",
                "suggestion": "检查折扣策略与采购成本变化，区分结构性与政策性毛利下滑",
            })

    days = len({r["date"] for r in rows})
    avg_stock = sum(r["stock_value"] for r in rows) / max(len(rows), 1)
    daily_cost = total_cost / max(days, 1)
    if daily_cost > 0:
        turnover_days = avg_stock / daily_cost
        if turnover_days > INVENTORY_TURNOVER_CEILING_DAYS:
            issues.append({
                "rule_id": "B-INVENTORY",
                "severity": "medium",
                "title": "库存周转超上限",
                "evidence": (
                    f"库存周转 {turnover_days:.0f} 天，"
                    f"超过 {INVENTORY_TURNOVER_CEILING_DAYS} 天上限"
                ),
                "suggestion": "定位积压品类，评估促销去化与采购节奏调整",
            })
    return issues


def detect_gmv_anomalies(
    rows: list[dict[str, Any]], *, mad_threshold: float
) -> list[dict[str, Any]]:
    """用 MAD 对每门店日 GMV 做异常检测。

    Args:
        rows: 合法数据行。
        mad_threshold: 稳健 z-score 阈值。

    Returns:
        list: 异常点列表。
    """
    by_store_day: dict[str, dict[Any, float]] = defaultdict(lambda: defaultdict(float))
    names: dict[str, str] = {}
    for row in rows:
        by_store_day[row["store_id"]][row["date"]] += row["gmv"]
        names[row["store_id"]] = row["store_name"]

    anomalies: list[dict[str, Any]] = []
    for store_id, day_gmv in by_store_day.items():
        series = sorted(day_gmv.items())
        values = [v for _, v in series]
        if len(values) < MIN_BASELINE_DAYS:
            continue
        median = statistics.median(values)
        mad = statistics.median([abs(v - median) for v in values])
        if mad == 0:
            continue
        for day, value in series:
            robust_z = 0.6745 * (value - median) / mad
            if abs(robust_z) >= mad_threshold:
                anomalies.append({
                    "rule_id": "MAD-GMV",
                    "severity": "high" if robust_z < 0 else "low",
                    "title": f"{'GMV 异常下跌' if robust_z < 0 else 'GMV 异常冲高'}",
                    "evidence": (
                        f"{names[store_id]}({store_id}) {day} GMV {value:.0f}，"
                        f"偏离中位数 {median:.0f}，稳健 z={robust_z:+.1f}"
                    ),
                    "suggestion": (
                        "核对当日客流/促销/系统故障等事件"
                        if robust_z < 0
                        else "确认是否由大促/团购等一次性事件驱动，评估可持续性"
                    ),
                })
    return anomalies


def main() -> int:
    """CLI 入口。检出 high 级问题时退出码为 1。"""
    parser = argparse.ArgumentParser(description="零售经营异常排查")
    parser.add_argument("--input", help="CSV/JSON 数据文件路径")
    parser.add_argument("--demo", action="store_true", help="使用内置演示数据")
    parser.add_argument("--mad-threshold", type=float, default=3.0, help="MAD 阈值")
    args = parser.parse_args()

    if args.demo:
        rows, quality = build_demo_rows(), []
    elif args.input:
        rows, quality = load_rows(args.input)
    else:
        parser.error("必须指定 --input 或 --demo")

    issues = check_indicator_rules(rows)
    issues.extend(detect_gmv_anomalies(rows, mad_threshold=args.mad_threshold))
    severity_order = {"high": 0, "medium": 1, "low": 2}
    issues.sort(key=lambda item: severity_order.get(item["severity"], 9))

    result = {
        "meta": {"row_count": len(rows), "mad_threshold": args.mad_threshold},
        "data_quality": quality,
        "issue_count": len(issues),
        "issues": issues,
    }
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2, default=str)
    print()
    return 1 if any(i["severity"] == "high" for i in issues) else 0


if __name__ == "__main__":
    sys.exit(main())
