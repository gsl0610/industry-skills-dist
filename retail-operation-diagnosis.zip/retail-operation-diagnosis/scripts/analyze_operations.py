#!/usr/bin/env python3
"""零售经营指标计算与对比排行。

仅依赖 Python 标准库，在沙箱内可直接运行。

用法：
    python3 analyze_operations.py --input daily.csv [--split-by store_id]
    python3 analyze_operations.py --demo [--split-by store_id]
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import sys
from collections import defaultdict
from datetime import date
from typing import Any

# ── 数据校验规则 ──────────────────────────────────────────────
REQUIRED_COLUMNS: tuple[str, ...] = (
    "date", "store_id", "store_name", "channel", "gmv", "orders",
    "visitors", "units", "cost", "new_customers",
    "returning_customers", "sku_sold", "sku_total", "stock_value",
)

NUMERIC_COLUMNS: tuple[str, ...] = (
    "gmv", "orders", "visitors", "units", "cost",
    "new_customers", "returning_customers", "sku_sold",
    "sku_total", "stock_value",
)


def _parse_date(value: str) -> date:
    """解析 YYYY-MM-DD 日期。"""
    return date.fromisoformat(value.strip())


def load_rows(source: str) -> tuple[list[dict[str, Any]], list[str]]:
    """加载并校验输入数据。

    Args:
        source: CSV/JSON 文件路径。

    Returns:
        tuple: (合法行列表, 数据质量问题列表)。
    """
    with open(source, encoding="utf-8-sig") as fh:
        text = fh.read()

    if source.endswith(".json"):
        raw_rows = json.loads(text)
    else:
        raw_rows = list(csv.DictReader(io.StringIO(text)))

    rows: list[dict[str, Any]] = []
    issues: list[str] = []
    for index, raw in enumerate(raw_rows, start=1):
        missing = [c for c in REQUIRED_COLUMNS if c not in raw or raw[c] in (None, "")]
        if missing:
            issues.append(f"第 {index} 行缺少必需列：{', '.join(missing)}")
            continue
        try:
            row: dict[str, Any] = {
                "date": _parse_date(raw["date"]),
                "store_id": str(raw["store_id"]).strip(),
                "store_name": str(raw["store_name"]).strip(),
                "channel": str(raw["channel"]).strip(),
            }
            for col in NUMERIC_COLUMNS:
                row[col] = float(raw[col])
        except (ValueError, TypeError) as exc:
            issues.append(f"第 {index} 行数据格式错误：{exc}")
            continue

        if row["orders"] > row["visitors"]:
            issues.append(f"第 {index} 行订单数大于访客数，数据矛盾")
            continue
        if row["units"] < row["orders"]:
            issues.append(f"第 {index} 行销售件数小于订单数，数据矛盾")
            continue
        if row["cost"] > row["gmv"]:
            issues.append(f"第 {index} 行成本大于 GMV，毛利率为负，请确认")
        rows.append(row)
    return rows, issues


def aggregate(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """汇总一组行的核心指标。"""
    gmv = sum(r["gmv"] for r in rows)
    orders = sum(r["orders"] for r in rows)
    visitors = sum(r["visitors"] for r in rows)
    units = sum(r["units"] for r in rows)
    cost = sum(r["cost"] for r in rows)
    new_c = sum(r["new_customers"] for r in rows)
    ret_c = sum(r["returning_customers"] for r in rows)
    sku_sold = sum(r["sku_sold"] for r in rows)
    sku_total = sum(r["sku_total"] for r in rows)
    days = len({r["date"] for r in rows})
    avg_stock = sum(r["stock_value"] for r in rows) / max(len(rows), 1)
    daily_cost = cost / max(days, 1)

    return {
        "days": days,
        "gmv": round(gmv, 2),
        "orders": int(orders),
        "visitors": int(visitors),
        "atv": round(gmv / orders, 2) if orders else None,
        "conversion_rate_percent": round(orders / visitors * 100, 2) if visitors else None,
        "units_per_order": round(units / orders, 2) if orders else None,
        "gross_margin_percent": round((gmv - cost) / gmv * 100, 2) if gmv else None,
        "repurchase_ratio_percent": (
            round(ret_c / (new_c + ret_c) * 100, 2) if (new_c + ret_c) else None
        ),
        "sell_through_percent": round(sku_sold / sku_total * 100, 2) if sku_total else None,
        "inventory_turnover_days": (
            round(avg_stock / daily_cost, 1) if daily_cost > 0 else None
        ),
    }


def split_periods(rows: list[dict[str, Any]]) -> tuple[list, list]:
    """按日期中点切分为基期与本期（等长可比）。"""
    dates = sorted({r["date"] for r in rows})
    mid = len(dates) // 2
    previous_set, current_set = set(dates[:mid]), set(dates[mid:])
    previous = [r for r in rows if r["date"] in previous_set]
    current = [r for r in rows if r["date"] in current_set]
    return previous, current


def compare_periods(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """计算等长环比。"""
    previous, current = split_periods(rows)
    if not previous or not current:
        return {"available": False, "reason": "数据不足以切分两个周期"}
    prev_agg, curr_agg = aggregate(previous), aggregate(current)

    changes: dict[str, Any] = {}
    for key in (
        "gmv", "atv", "conversion_rate_percent", "units_per_order",
        "gross_margin_percent", "repurchase_ratio_percent",
        "sell_through_percent", "inventory_turnover_days",
    ):
        old, new = prev_agg.get(key), curr_agg.get(key)
        if old in (None, 0) or new is None:
            continue
        changes[key] = {
            "previous": old,
            "current": new,
            "relative_change_percent": round((new - old) / old * 100, 2),
        }
    return {
        "available": True,
        "previous_days": prev_agg["days"],
        "current_days": curr_agg["days"],
        "rate_changes": changes,
    }


def rank_stores(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """按 GMV 对门店排名并附核心指标。"""
    by_store: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_store[row["store_id"]].append(row)

    ranking = []
    for store_id, store_rows in by_store.items():
        agg = aggregate(store_rows)
        ranking.append({
            "store_id": store_id,
            "store_name": store_rows[0]["store_name"],
            "channel": store_rows[0]["channel"],
            **{k: agg[k] for k in (
                "gmv", "atv", "conversion_rate_percent",
                "gross_margin_percent", "sell_through_percent",
            )},
        })
    ranking.sort(key=lambda item: item["gmv"], reverse=True)
    return ranking


def best_worst_days(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """按日 GMV 找出最高/最低的三个日期。"""
    by_day: dict[date, float] = defaultdict(float)
    for row in rows:
        by_day[row["date"]] += row["gmv"]
    ordered = sorted(by_day.items(), key=lambda kv: kv[1], reverse=True)
    return {
        "best": [{"date": str(d), "gmv": round(v, 2)} for d, v in ordered[:3]],
        "worst": [{"date": str(d), "gmv": round(v, 2)} for d, v in ordered[-3:]],
    }


def build_demo_rows() -> list[dict[str, Any]]:
    """构造演示数据（两周、两门店，含预埋问题）。

    预埋情节：线上商城（S002）第二周访客增长但转化率骤降，
    连带率同步下滑；线下旗舰店（S001）经营平稳。
    """
    weekday_factor = [0.90, 0.95, 1.00, 1.02, 1.06, 1.28, 1.32]
    rows: list[dict[str, Any]] = []
    base = date(2026, 7, 20)
    stores = {
        "S001": {"name": "天河旗舰店", "channel": "offline",
                 "visitors": 900, "conv": 0.30, "atv": 420.0, "upt": 2.1,
                 "margin": 0.46},
        "S002": {"name": "线上商城", "channel": "online",
                 "visitors": 5200, "conv": 0.028, "atv": 230.0, "upt": 1.6,
                 "margin": 0.38},
    }
    for day_offset in range(14):
        current = date.fromordinal(base.toordinal() + day_offset)
        week2 = day_offset >= 7
        factor = weekday_factor[current.weekday()]
        for store_id, cfg in stores.items():
            visitors = cfg["visitors"] * factor * (1.35 if (store_id == "S002" and week2) else 1.0)
            conv = cfg["conv"] * (0.55 if (store_id == "S002" and week2) else 1.0)
            orders = round(visitors * conv)
            upt = cfg["upt"] * (0.75 if (store_id == "S002" and week2) else 1.0)
            gmv = round(orders * cfg["atv"], 2)
            rows.append({
                "date": current,
                "store_id": store_id,
                "store_name": cfg["name"],
                "channel": cfg["channel"],
                "gmv": gmv,
                "orders": orders,
                "visitors": round(visitors),
                "units": round(orders * upt),
                "cost": round(gmv * (1 - cfg["margin"]), 2),
                "new_customers": round(orders * (0.62 if store_id == "S002" else 0.35)),
                "returning_customers": round(orders * (0.38 if store_id == "S002" else 0.65)),
                "sku_sold": 320 if store_id == "S001" else (540 if not week2 else 410),
                "sku_total": 450 if store_id == "S001" else 900,
                "stock_value": 580000.0 if store_id == "S001" else 1250000.0,
            })
    return rows


def main() -> int:
    """CLI 入口。"""
    parser = argparse.ArgumentParser(description="零售经营指标计算")
    parser.add_argument("--input", help="CSV/JSON 数据文件路径")
    parser.add_argument("--demo", action="store_true", help="使用内置演示数据")
    parser.add_argument("--split-by", choices=["store_id", "channel"], help="拆分维度")
    args = parser.parse_args()

    if args.demo:
        rows, issues = build_demo_rows(), []
    elif args.input:
        rows, issues = load_rows(args.input)
    else:
        parser.error("必须指定 --input 或 --demo")

    result: dict[str, Any] = {
        "meta": {"row_count": len(rows)},
        "data_quality": issues,
        "overall": aggregate(rows),
        "period_comparison": compare_periods(rows),
        "best_worst_days": best_worst_days(rows),
    }
    if args.split_by == "store_id":
        result["store_ranking"] = rank_stores(rows)
    elif args.split_by == "channel":
        by_channel: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in rows:
            by_channel[row["channel"]].append(row)
        result["channel_breakdown"] = {
            name: aggregate(group) for name, group in by_channel.items()
        }

    json.dump(result, sys.stdout, ensure_ascii=False, indent=2, default=str)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
