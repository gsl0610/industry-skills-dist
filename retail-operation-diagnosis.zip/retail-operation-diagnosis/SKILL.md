---
name: retail-operation-diagnosis
description: 当用户需要分析零售门店或电商的销售额/GMV 变动原因、评估经营健康度、解读客单价/转化率/连带率/毛利率/动销率/库存周转等零售核心指标、排查经营异常（转化率突降、库存积压、动销不足）或生成日/周/月度经营诊断报告时使用此技能。适用于连锁零售、品牌直营、商超便利及线上商城。
version: 1.0.0
x-industry: retail
x-owner: retail-ops-team
x-compliance: internal
allowedTools:
  - read_file
  - execute_command
---

# 零售经营诊断

## 何时使用

在以下任一情形使用本技能：

- 用户提供了门店/电商经营数据（CSV/JSON，含 GMV、订单、访客、成本等）并要求诊断。
- 用户询问"为什么本周 GMV 下滑""哪个门店有问题""动销怎么样"。
- 用户要求出具经营诊断报告或经营复盘材料。

不适用场景：选品企划、会员权益设计、供应链物流调度——这些请转交其他技能。

## 执行步骤

按顺序执行，不得跳步：

1. **确认数据与期间**
   识别输入字段与分析区间，明确对比基期。缺必需字段时先索取，不做假设。

2. **数据校验**
   运行脚本查看 `data_quality`，发现矛盾（如订单>访客、成本>GMV）时先向用户确认，
   不得带着脏数据下结论。

3. **指标计算**
   执行 `scripts/analyze_operations.py` 得出事实层数据：期间汇总、等长环比、门店排行、最佳/最差日。
   所有数字必须来自脚本输出，禁止口算或估算。

4. **异常排查**
   执行 `scripts/diagnose_issues.py`，获取规则引擎命中的指标异常与 MAD 检测的 GMV 异常点。

5. **归因分析**
   按 `references/diagnosis-playbook.md` 的「人—货—场」决策树逐层下钻，
   把异常指标映射到流量/商品/客群维度。每条结论标注三级证据等级：
   数据可验证结论 / 待验证假设 / 相关非因果。

6. **输出报告**
   套用 `assets/diagnosis-report-template.md` 的六段结构。
   环比必须确认两期等长且星期结构对齐，否则在报告中显式声明不可比。

## 脚本与资源清单

### scripts/analyze_operations.py — 指标计算与对比排行

```bash
# 全量指标 + 环比（默认按周对比）
python3 scripts/analyze_operations.py --input daily.csv

# 按门店拆分对比
python3 scripts/analyze_operations.py --input daily.csv --split-by store_id

# 内置演示数据（熟悉输出结构 / 演示用）
python3 scripts/analyze_operations.py --demo --split-by store_id
```

输出 JSON：`overall`（期间汇总）、`period_comparison`（等长环比，两期不等长则 `available=false`）、
`store_ranking` 或 `channel_breakdown`、`best_worst_days`。

### scripts/diagnose_issues.py — 经营异常排查

```bash
# 规则引擎 + MAD 异常检测
python3 scripts/diagnose_issues.py --input daily.csv

# 调整异常灵敏度（默认 3.0，越小越敏感）
python3 scripts/diagnose_issues.py --input daily.csv --mad-threshold 2.5
```

输出 `issues` 列表，每条含 `rule_id`、`severity`（high/medium/low）、`evidence`、`suggestion`。
检出 high 级问题时退出码为 1。

### 参考资料与模板

| 资源 | 用途 |
| --- | --- |
| `references/metric-definitions.md` | 指标口径唯一权威定义，引用指标必标口径 |
| `references/diagnosis-playbook.md` | 人—货—场归因决策树，禁止跳层下结论 |
| `references/benchmarks.md` | 行业基准区间，仅用于定位方向，须附品类差异提示 |
| `assets/diagnosis-report-template.md` | 报告输出模板（六段结构） |
| `assets/sample_daily_sales.csv` | 标准输入格式样例 |

### 输入数据格式

CSV 或 JSON 数组，每行一个「门店 × 日期」记录，必需列：

```
date, store_id, store_name, channel, gmv, orders, visitors,
units, cost, new_customers, returning_customers, sku_sold, sku_total, stock_value
```

校验规则：orders ≤ visitors；units ≥ orders；cost ≤ gmv；日期 YYYY-MM-DD。
校验失败在输出的 `data_quality` 中列出，**不得忽略**。

## 注意事项与边界

- **口径一致性**：同一报告中同一指标必须用同一口径；与用户既有报表口径不一致时显式声明差异。
- **环比可比性**：两期必须等长且星期结构对齐；大促期与平销期不可直接环比，应做同比或剔除大促日。
- **基准引用限制**：行业基准仅用于定位排查方向，引用时必须附品类差异提示，不得作为考核结论。
- **结论分级**：禁止把假设写成事实，禁止把时间重合写成因果。
- **绝对承诺红线**：不得出现"保证提升""必然增长"等表述，目标一律表达为"目标区间 + 验证方式 + 复盘节点"。
- **单店外推限制**：单店/单渠道结论不得外推至全盘，必须完成同城同渠道横向对比后才可下整体性结论。
