#!/usr/bin/env python3
"""智能客服意图路由与效率预估（模拟）。

仅依赖 Python 标准库。合并 intent_router、service_metrics、quality_check。

用法：
    python3 intent_router.py --demo
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any

INTENT_TREE = {
    "ecommerce": {
        "售前咨询": ["商品信息查询", "促销活动咨询", "库存查询", "比价议价"],
        "售后退换": ["退货申请", "换货申请", "退款进度", "质量问题反馈"],
        "物流查询": ["物流状态", "催发货", "修改地址", "签收异常"],
        "账户服务": ["会员权益", "积分查询", "账户安全", "密码重置"],
        "投诉建议": ["服务投诉", "商品投诉", "意见建议"],
    },
    "finance": {
        "产品咨询": ["理财产品介绍", "收益率查询", "风险等级", "购买流程"],
        "账户服务": ["余额查询", "交易明细", "账户解冻", "信息变更"],
        "业务办理": ["开户", "贷款申请", "信用卡申请", "申购赎回"],
        "投诉建议": ["服务投诉", "收费争议", "意见建议"],
    },
}

ROUTING_RULES = {
    "商品信息查询": "knowledge_base", "促销活动咨询": "knowledge_base",
    "库存查询": "ai_auto", "比价议价": "human",
    "退货申请": "ai_auto", "换货申请": "ai_auto",
    "退款进度": "ai_auto", "质量问题反馈": "human",
    "物流状态": "ai_auto", "催发货": "ai_auto",
    "修改地址": "ai_auto", "签收异常": "human",
    "会员权益": "knowledge_base", "积分查询": "ai_auto",
    "账户安全": "human", "密码重置": "ai_auto",
    "服务投诉": "human", "商品投诉": "human", "意见建议": "knowledge_base",
}


def build_routing(domain: str) -> dict[str, Any]:
    """构建意图路由规则。"""
    tree = INTENT_TREE.get(domain, INTENT_TREE["ecommerce"])
    rules = {}
    for primary, secondaries in tree.items():
        for sec in secondaries:
            handler = ROUTING_RULES.get(sec, "ai_auto")
            rules[sec] = {"primary_intent": primary, "handler": handler}
    ai_count = sum(1 for r in rules.values() if r["handler"] == "ai_auto")
    human_count = sum(1 for r in rules.values() if r["handler"] == "human")
    return {
        "domain": domain,
        "intent_tree": tree,
        "routing_rules": rules,
        "summary": {
            "total_intents": len(rules),
            "ai_auto": ai_count,
            "human": human_count,
            "knowledge_base": len(rules) - ai_count - human_count,
            "ai_automation_rate_percent": round(ai_count / max(len(rules), 1) * 100, 2),
        },
        "fallback": {"handler": "human", "reason": "未识别意图兜底转人工"},
    }


def estimate_metrics(daily_volume: int, ai_rate: float, human_agents: int) -> dict[str, Any]:
    """预估客服效率指标。"""
    ai_volume = int(daily_volume * ai_rate)
    human_volume = daily_volume - ai_volume
    ai_avg_response = 3  # 秒
    human_avg_response = 45  # 秒
    human_capacity = human_agents * 200  # 每人每日处理量
    return {
        "daily_volume": daily_volume,
        "ai_handled": ai_volume,
        "human_handled": human_volume,
        "ai_rate_percent": round(ai_rate * 100, 2),
        "avg_response_seconds": round((ai_volume * ai_avg_response + human_volume * human_avg_response) / daily_volume, 1),
        "transfer_to_human_rate_percent": round(human_volume / daily_volume * 100, 2),
        "human_capacity": human_capacity,
        "human_utilization_percent": round(human_volume / max(human_capacity, 1) * 100, 2),
        "recommendation": "人力充足" if human_volume < human_capacity else "建议增加人力或提升AI自动化率",
    }


def quality_check(dialog: str) -> dict[str, Any]:
    """对话质检。"""
    forbidden = ["最", "第一", "唯一", "保证", "根治", "包治"]
    found = [w for w in forbidden if w in dialog]
    has_closing = any(w in dialog for w in ["祝您", "感谢", "再见", "还有其他"])
    has_negative = any(w in dialog for w in ["不知道", "不归我管", "你自己看"])
    issues = []
    if found:
        issues.append({"rule": "禁用词", "level": "high", "terms": found})
    if not has_closing:
        issues.append({"rule": "缺少结束语", "level": "medium"})
    if has_negative:
        issues.append({"rule": "负面情绪", "level": "medium"})
    return {
        "checks": issues,
        "verdict": "不通过" if any(i["level"] == "high" for i in issues) else "通过",
        "total_issues": len(issues),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="智能客服意图路由与效率预估（模拟）")
    parser.add_argument("--domain", choices=["ecommerce", "finance"], default="ecommerce")
    parser.add_argument("--daily-volume", type=int, default=5000)
    parser.add_argument("--ai-rate", type=float, default=0.6)
    parser.add_argument("--human-agents", type=int, default=10)
    parser.add_argument("--demo", action="store_true")
    args = parser.parse_args()

    demo_dialog = "您好，请问有什么可以帮您？这个商品目前有现货，最晚明天发货。保证正品，祝您购物愉快。"
    result = {
        "intent_routing": build_routing(args.domain),
        "service_metrics": estimate_metrics(args.daily_volume, args.ai_rate, args.human_agents),
        "quality_check": quality_check(demo_dialog),
        "note": "模拟数据，非真实客服运营数据。",
    }
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
