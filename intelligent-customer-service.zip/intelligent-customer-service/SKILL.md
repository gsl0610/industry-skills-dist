---
name: intelligent-customer-service
description: 当用户需要设计智能客服方案、构建意图识别路由、配置客服话术知识库、评估客服效率指标、或做客服对话质检时使用此技能。适用于电商客服、售后支持、咨询接待等场景。
version: 1.0.0
x-industry: marketing
x-owner: marketing-team
x-compliance: internal
visibility: internal
allowedTools:
  - read_file
  - execute_command
---

# 智能客服

## 何时使用

- 用户要求设计智能客服方案（意图路由、话术库、转人工规则）。
- 用户询问"客服怎么分流""转人工率多少""响应时长怎么优化"。
- 用户要求构建意图识别分类体系。
- 用户要求做客服对话质检（合规、话术规范）。

不适用场景：外呼营销（用 intelligent-outbound-call）、私域社群运营（用 CRM 相关）。

## 执行步骤

1. **解析客服需求**
   提取：业务场景（售前/售后/咨询）、渠道、日均咨询量、现有团队规模。

2. **构建意图路由**
   运行 `scripts/intent_router.py` 生成意图分类与路由规则：
   ```bash
   python3 scripts/intent_router.py --domain ecommerce --scenarios "售前咨询,售后退换,物流查询,投诉"
   ```

3. **评估客服效率**
   运行 `scripts/service_metrics.py` 估算效率指标：
   ```bash
   python3 scripts/service_metrics.py --daily-volume 5000 --ai-rate 0.6 --human-agents 10
   ```

4. **对话质检**
   运行 `scripts/quality_check.py` 对话术做质检：
   ```bash
   python3 scripts/quality_check.py --dialog dialog.txt
   ```

5. **产出客服方案**
   套用 `assets/service-plan-template.md`。

## 脚本与资源清单

| 脚本 | 用途 |
| --- | --- |
| `scripts/intent_router.py` | 意图分类与路由规则生成 |
| `scripts/service_metrics.py` | 客服效率指标预估（响应时长/转人工率/吞吐） |
| `scripts/quality_check.py` | 对话质检（合规/话术规范） |

| 资源 | 用途 |
| --- | --- |
| `references/intent-taxonomy.md` | 意图分类体系 |
| `references/service-sla.md` | 客服 SLA 标准 |
| `assets/service-plan-template.md` | 客服方案模板 |

## 注意事项与边界

- 意图分类须覆盖主要场景，未覆盖的须设计兜底转人工。
- 转人工阈值须可配置，不同业务敏感度不同。
- 质检规则须符合行业合规（不得承诺无法兑现的售后政策）。
- 模拟数据须标注。
